@echo off
setlocal
cd /d "%~dp0"
if not exist "MANIFEST.json" goto incomplete
if exist ".venv\Scripts\python.exe" goto verify
py -3.12 -m venv .venv >nul 2>&1
if not errorlevel 1 goto verify
py -3.11 -m venv .venv >nul 2>&1
if not errorlevel 1 goto verify
py -3 -c "import sys; assert (3,10) <= sys.version_info[:2] < (3,14)" >nul 2>&1
if errorlevel 1 goto fallback
py -3 -m venv .venv
if not errorlevel 1 goto verify
:fallback
python -c "import sys; assert (3,10) <= sys.version_info[:2] < (3,14)" >nul 2>&1
if errorlevel 1 goto no_python
python -m venv .venv
if errorlevel 1 goto failed
:verify
".venv\Scripts\python.exe" verify_package.py
if errorlevel 1 goto incomplete
".venv\Scripts\python.exe" -m pip install -r requirements.txt > preparacao.log 2>&1
if errorlevel 1 goto dependencies_failed
start "" ".venv\Scripts\pythonw.exe" launch.py
exit /b 0
:dependencies_failed
type preparacao.log
echo Envie preparacao.log desta pasta para diagnostico.
goto failed
:no_python
echo Instale Python 3.12: https://www.python.org/downloads/windows/
echo Marque Add Python to PATH. Depois abra INICIAR.cmd novamente.
goto failed
:incomplete
echo Use Extrair Tudo no ZIP. Abra INICIAR.cmd na pasta extraida.
echo Se persistir, o pacote esta incompleto ou foi alterado.
:failed
pause
exit /b 1
