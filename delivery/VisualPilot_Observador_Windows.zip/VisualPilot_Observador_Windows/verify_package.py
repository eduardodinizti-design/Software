"""Standard-library integrity check before dependency setup."""
import hashlib
import json
from pathlib import Path


def verify(root):
    manifest=json.loads((root/'MANIFEST.json').read_text())
    for relative, expected in manifest['files'].items():
        target=(root/relative).resolve()
        if not target.is_relative_to(root.resolve()):raise ValueError('Caminho invalido no manifesto')
        if not target.is_file():raise ValueError('Arquivo ausente: '+relative)
        if hashlib.sha256(target.read_bytes()).hexdigest()!=expected:
            raise ValueError('Arquivo alterado: '+relative)
    return len(manifest['files'])


if __name__=='__main__':
    try: print('Integridade OK:',verify(Path(__file__).resolve().parent),'arquivos')
    except Exception as exc: print('PACOTE INCOMPLETO/ALTERADO:',exc);raise SystemExit(1)
