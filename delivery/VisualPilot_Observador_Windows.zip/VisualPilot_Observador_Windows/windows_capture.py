"""Read-only native Windows capture. No mouse, keyboard, focus or restore calls.

Boxes are physical desktop (x,y,width,height). Blockers are frame-relative.
The snapshot checks narrow races; they cannot make desktop capture atomic.
"""
from contextlib import contextmanager
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import ntpath
import sys
import time

ALLOWED_EXECUTABLES = frozenset({'pppoker.exe', 'ppclient.exe'})
MAX_PIXELS = 36_000_000


class CaptureError(RuntimeError):
    pass


def _authorized(window):
    return (not window.get('identity_error') and
            ntpath.basename(window.get('exe', '')).casefold() in ALLOWED_EXECUTABLES)


class _NativeWindows:
    def __init__(self):
        if sys.platform != 'win32':
            raise CaptureError('WINDOWS_REQUIRED: a captura nativa exige Windows.')
        self.user = ctypes.WinDLL('user32', use_last_error=True)
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        u, k = self.user, self.kernel
        signatures = [
            (u.EnumWindows, [self.callback_type, wintypes.LPARAM], wintypes.BOOL),
            (u.IsWindowVisible, [wintypes.HWND], wintypes.BOOL),
            (u.IsIconic, [wintypes.HWND], wintypes.BOOL),
            (u.GetWindowThreadProcessId, [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)], wintypes.DWORD),
            (u.GetWindowTextLengthW, [wintypes.HWND], ctypes.c_int),
            (u.GetWindowTextW, [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int], ctypes.c_int),
            (u.GetClientRect, [wintypes.HWND, ctypes.POINTER(wintypes.RECT)], wintypes.BOOL),
            (u.ClientToScreen, [wintypes.HWND, ctypes.POINTER(wintypes.POINT)], wintypes.BOOL),
            (u.GetWindowRect, [wintypes.HWND, ctypes.POINTER(wintypes.RECT)], wintypes.BOOL),
            (k.OpenProcess, [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE),
            (k.QueryFullProcessImageNameW, [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL),
            (k.GetProcessTimes, [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4, wintypes.BOOL),
            (k.CloseHandle, [wintypes.HANDLE], wintypes.BOOL),
        ]
        for fn, argtypes, restype in signatures:
            fn.argtypes, fn.restype = argtypes, restype
        try:
            self.set_dpi = u.SetThreadDpiAwarenessContext
            self.set_dpi.argtypes = [ctypes.c_void_p]
            self.set_dpi.restype = ctypes.c_void_p
        except AttributeError as exc:
            raise CaptureError('DPI_UNAVAILABLE: Windows com Per-Monitor V2 necessário.') from exc
        self.dwm = ctypes.WinDLL('dwmapi', use_last_error=True)
        self.dwm.DwmGetWindowAttribute.argtypes = [wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
        self.dwm.DwmGetWindowAttribute.restype = ctypes.c_long

    @contextmanager
    def physical_coordinates(self):
        previous = self.set_dpi(ctypes.c_void_p(-4))
        if not previous:
            raise CaptureError('DPI_CONTEXT_FAILED: não foi possível obter pixels físicos.')
        try:
            yield
        finally:
            self.set_dpi(previous)

    def _identity(self, hwnd):
        pid = wintypes.DWORD()
        if not self.user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid)):
            raise CaptureError('PROCESS_QUERY_FAILED: PID indisponível.')
        handle = self.kernel.OpenProcess(0x1000, False, pid.value)
        if not handle:
            raise CaptureError(f'PROCESS_ACCESS_DENIED: PID {pid.value}.')
        try:
            length = wintypes.DWORD(32768)
            buffer = ctypes.create_unicode_buffer(length.value)
            if not self.kernel.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(length)):
                raise CaptureError('PROCESS_QUERY_FAILED: executável indisponível.')
            times = [wintypes.FILETIME() for _ in range(4)]
            if not self.kernel.GetProcessTimes(handle, *[ctypes.byref(v) for v in times]):
                raise CaptureError('PROCESS_QUERY_FAILED: identidade temporal indisponível.')
            created = (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime
            return {'pid': pid.value, 'exe': buffer.value, 'process_created': created}
        finally:
            self.kernel.CloseHandle(handle)

    def _client_box(self, hwnd):
        rect = wintypes.RECT()
        if not self.user.GetClientRect(hwnd, ctypes.byref(rect)):
            raise CaptureError('INVALID_GEOMETRY: GetClientRect falhou.')
        point = wintypes.POINT(rect.left, rect.top)
        if not self.user.ClientToScreen(hwnd, ctypes.byref(point)):
            raise CaptureError('INVALID_GEOMETRY: ClientToScreen falhou.')
        return [point.x, point.y, rect.right - rect.left, rect.bottom - rect.top]

    def snapshot(self):
        rows = []
        failures = []
        def visit(hwnd, _):
            try:
                visible = bool(self.user.IsWindowVisible(hwnd))
                if not visible:
                    return True
                title = ctypes.create_unicode_buffer(self.user.GetWindowTextLengthW(hwnd) + 1)
                self.user.GetWindowTextW(hwnd, title, len(title))
                rect = wintypes.RECT()
                if not self.user.GetWindowRect(hwnd, ctypes.byref(rect)):
                    raise CaptureError('WINDOW_GEOMETRY_QUERY_FAILED')
                cloaked = wintypes.DWORD()
                hr = self.dwm.DwmGetWindowAttribute(hwnd, 14, ctypes.byref(cloaked), ctypes.sizeof(cloaked))
                row = {'hwnd': int(hwnd), 'title': title.value, 'visible': visible,
                       'minimized': bool(self.user.IsIconic(hwnd)),
                       'cloaked': bool(cloaked.value) if hr == 0 else False,
                       'outer_box': [rect.left, rect.top, rect.right-rect.left, rect.bottom-rect.top]}
                try:
                    row.update(self._identity(hwnd))
                except CaptureError as exc:
                    row.update({'exe': '', 'pid': None, 'identity_error': str(exc)})
                if _authorized(row):
                    try:
                        row['box'] = self._client_box(hwnd)
                    except CaptureError as exc:
                        row['geometry_error'] = str(exc)
                rows.append(row)
                return True
            except Exception as exc:
                failures.append(str(exc))
                return False
        callback = self.callback_type(visit)
        success = self.user.EnumWindows(callback, 0)
        if failures or not success:
            raise CaptureError('WINDOW_ENUMERATION_FAILED: ' + '; '.join(failures))
        return rows


def _select(rows, hwnd):
    targets = [w for w in rows if w['hwnd'] == hwnd and _authorized(w)]
    if len(targets) != 1:
        raise CaptureError('WINDOW_NOT_FOUND: o HWND não pertence a um processo PPPoker autorizado.')
    window = targets[0]
    if window.get('minimized') or window.get('cloaked') or not window.get('visible', True):
        raise CaptureError('WINDOW_UNAVAILABLE: janela minimizada ou invisível.')
    box = window.get('box')
    if not box or len(box) != 4 or box[2] <= 0 or box[3] <= 0 or box[2] * box[3] > MAX_PIXELS:
        raise CaptureError('INVALID_GEOMETRY: área cliente ausente, vazia ou acima de 36 megapixels.')
    return window


def _blockers(rows, target):
    x,y,w,h = target['box']
    result = []
    for row in rows:
        if row['hwnd'] == target['hwnd']:
            break
        if row.get('minimized') or row.get('cloaked') or not row.get('visible', True):
            continue
        bx,by,bw,bh = row['outer_box']
        left,top,right,bottom = max(x,bx),max(y,by),min(x+w,bx+bw),min(y+h,by+bh)
        if right > left and bottom > top:
            result.append({'hwnd': row['hwnd'], 'box':[left-x,top-y,right-left,bottom-top]})
    return result


def _signature(window):
    return (window['hwnd'], window['pid'], window.get('process_created'),
            window['exe'].casefold(), tuple(window['box']))


def list_windows(*, _provider=None):
    provider = _provider or _NativeWindows()
    with provider.physical_coordinates():
        return [w for w in provider.snapshot() if _authorized(w)]



def diagnostic_windows(*, _provider=None):
    """Explain likely poker windows rejected by identity checks; never authorizes them."""
    provider = _provider or _NativeWindows()
    with provider.physical_coordinates():
        rows = provider.snapshot()
    results = []
    for row in rows:
        title = row.get('title', '').casefold()
        if not _authorized(row) and not any(word in title for word in ('poker', 'mtt', 'nlh', 'plo', 'unity')):
            continue
        item = dict(row)
        if row.get('identity_error'):
            item['diagnostic_status'] = 'PROCESS_QUERY_FAILED'
        elif not _authorized(row):
            item['diagnostic_status'] = 'EXECUTABLE_NOT_ALLOWED'
        elif row.get('minimized') or row.get('cloaked'):
            item['diagnostic_status'] = 'WINDOW_UNAVAILABLE'
        elif row.get('geometry_error'):
            item['diagnostic_status'] = 'INVALID_GEOMETRY'
        else:
            item['diagnostic_status'] = 'IDENTITY_ALLOWED'
        results.append(item)
    return results


def capture_window(hwnd, *, _provider=None, _grab=None):
    """Return (BGR ndarray, metadata), rejecting stale identity/geometry.

    `_provider` and `_grab` are contract-test seams. Images may include overlays:
    metadata blockers must be used by downstream table detection before OCR.
    """
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise CaptureError('INVALID_HWND')
    from PIL import ImageGrab
    import numpy as np
    provider = _provider or _NativeWindows()
    grab = _grab or ImageGrab.grab
    with provider.physical_coordinates():
        before = provider.snapshot()
        target = _select(before, hwnd)
        blockers = _blockers(before, target)
        x,y,w,h = target['box']
        started = time.monotonic()
        try:
            image = grab(bbox=(x,y,x+w,y+h), all_screens=True)
        except Exception as exc:
            raise CaptureError(f'CAPTURE_FAILED: {exc}') from exc
        after = provider.snapshot()
        current = _select(after, hwnd)
        if _signature(target) != _signature(current):
            raise CaptureError('WINDOW_CHANGED: identidade ou geometria mudou durante a captura; recapture.')
        if blockers != _blockers(after, current):
            raise CaptureError('VISIBILITY_CHANGED: sobreposição mudou durante a captura; recapture.')
        if image.size != (w,h):
            raise CaptureError('FRAME_SIZE_MISMATCH: pixels capturados não correspondem à área cliente.')
        rgb = np.asarray(image.convert('RGB'))
        return rgb[:, :, ::-1].copy(), {
            'window': dict(current), 'blockers': [b['box'] for b in blockers],
            'blocker_windows': blockers, 'capture_started_monotonic': started,
            'capture_finished_monotonic': time.monotonic(),
            'timestamp_utc': datetime.now(timezone.utc).isoformat(),
            'capture_backend':'PIL_ImageGrab_desktop_client_bbox',
            'coordinates':'physical_pixels', 'color_format':'BGR',
            'native_windows_validated':False,
            'limitations':['Desktop capture contains overlays; blockers require downstream rejection.',
                           'Checks are before/after snapshots, not atomic capture.'],
        }
