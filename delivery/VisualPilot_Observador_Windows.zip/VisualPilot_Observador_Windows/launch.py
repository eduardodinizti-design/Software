"""Keep pythonw startup failures visible and save their traceback."""
import os
import runpy
import traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)
with (ROOT/'inicializacao.log').open('w',encoding='utf-8') as log:
    import sys
    sys.stdout=sys.stderr=log
    try:
        from verify_package import verify
        verify(ROOT)
        runpy.run_path(str(ROOT/'app.py'),run_name='__main__')
    except Exception:
        traceback.print_exc();log.flush()
        import ctypes
        ctypes.windll.user32.MessageBoxW(None,'Falha ao iniciar. Envie inicializacao.log desta pasta.','VisualPilot: diagnostico',0x10)
        raise SystemExit(1)
