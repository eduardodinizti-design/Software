"""Read-only Windows observer: fresh window capture, pixel proposals, no input injection."""
import io
import json
import platform
import queue
import sys
import threading
import time
import traceback
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT/'reader'), str(ROOT)]
import cv2
from PIL import Image, ImageTk
from inspect_cards import inspect
from visualpilot.pppoker.automatic_table_crops import detect_table_crops
from windows_capture import list_windows, capture_window, diagnostic_windows
from check_init import configure_tesseract

LIMIT = 50 * 1024 * 1024


def analyze_frame(frame, metadata):
    proposals = detect_table_crops(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB),
                                  blockers=metadata.get('blockers', []))
    rows = []
    for index, proposal in enumerate(proposals):
        row = dict(proposal.to_dict(), capture_index=index+1)
        if proposal.status == 'COMPLETE_CANDIDATE':
            try:
                row['reading'] = inspect(frame, proposal.box)
            except Exception as exc:
                row.update(error=str(exc), traceback=traceback.format_exc())
        rows.append(row)
    return {'status':'EXPERIMENTAL_SNAPSHOT', 'automatic_tracking':False,
            'actions_allowed':False, 'capture':metadata, 'tables':rows,
            'warning':'Snapshot only; indices are not persistent table identities.'}


def export_diagnostic(report, frame, directory, truth='', limit=LIMIT):
    directory.mkdir(parents=True, exist_ok=True)
    payload = dict(report, user_observation=truth, saved_at=time.time())
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('diagnostico.json', json.dumps(payload, ensure_ascii=False, indent=2))
        if frame is not None:
            ok, encoded = cv2.imencode('.png', frame)
            if not ok: raise RuntimeError('Falha ao codificar a captura PNG')
            archive.writestr('captura.png', encoded.tobytes())
    data = buffer.getvalue()
    used = sum(p.stat().st_size for p in directory.rglob('*') if p.is_file())
    if used+len(data)>limit:
        raise RuntimeError('Limite de 50 MiB em resultados. Arquive os ZIPs antes de salvar mais.')
    path = directory / f'diagnostico-{time.time_ns()}.zip'
    with path.open('xb') as output: output.write(data)
    return path


class App:
    def __init__(self, root):
        self.root=root; self.queue=queue.Queue(); self.busy=False
        self.windows=[]; self.frame=None; self.report=None
        self.version=json.loads((ROOT/'VERSION.json').read_text())
        root.title('VisualPilot — Observador Windows '+self.version['version'])
        root.geometry('1000x820')
        ttk.Label(root,text='OBSERVAÇÃO EXPERIMENTAL • SEM CLIQUES NO PPPoker').pack(pady=6)
        ttk.Label(root,text='1. Abra uma mesa azul visível. 2. Atualize janelas. 3. Capture e leia.').pack()
        self.selector=ttk.Combobox(root,state='readonly',width=100);self.selector.pack(pady=6)
        toolbar=ttk.Frame(root);toolbar.pack()
        for title,fn in [('Atualizar janelas',self.refresh),('Capturar e ler',self.capture),('Salvar diagnóstico ZIP',self.save)]:
            ttk.Button(toolbar,text=title,command=fn).pack(side='left',padx=6)
        self.status=tk.StringVar(value='Inicializando...')
        ttk.Label(root,textvariable=self.status,wraplength=950).pack(pady=6)
        self.details=tk.Text(root,height=8,width=115,state='disabled');self.details.pack()
        self.preview=ttk.Label(root);self.preview.pack()
        ttk.Label(root,text='Cartas que você vê / observações (opcional):').pack()
        self.truth=ttk.Entry(root,width=95);self.truth.pack()
        ttk.Label(root,text='Ao mover/redimensionar, capture novamente: a janela e as mesas serão localizadas de novo.').pack(pady=4)
        root.after(100,self.poll)
        self.refresh()

    def clear(self):
        self.frame=None;self.report=None;self.preview.configure(image='')
        self.details.configure(state='normal');self.details.delete('1.0',tk.END);self.details.configure(state='disabled')

    def failure(self, exc):
        self.report={'status':'ERROR','error':str(exc),'traceback':traceback.format_exc(),
                     'version':self.version,'actions_allowed':False, 'windows':self.windows,
                     'platform':platform.platform()}
        self.status.set('ERRO: '+str(exc)+' — use Salvar diagnóstico ZIP.')

    def refresh(self):
        if self.busy:return
        self.clear()
        try:
            self.windows=list_windows()
            self.selector['values']=[f"{w.get('title','')} | {w.get('exe','')} | PID {w.get('pid')} | HWND {w['hwnd']}" for w in self.windows]
            if self.windows:self.selector.current(0)
            else:self.selector.set('')
            self.report={'status':'WINDOWS_LISTED','version':self.version,'windows':self.windows,'diagnostic_windows':diagnostic_windows(),'actions_allowed':False}
            self.status.set(f'{len(self.windows)} janela(s) nativa(s) encontrada(s).' if self.windows else 'PPPoker/PPClient não localizado. Abra o cliente e atualize; salve diagnóstico se persistir.')
        except Exception as exc:self.failure(exc)

    def capture(self):
        if self.busy:return
        idx=self.selector.current()
        if not 0<=idx<len(self.windows):
            messagebox.showinfo('Janela','Abra o PPPoker e clique Atualizar janelas.');return
        selected=dict(self.windows[idx]);hwnd=selected['hwnd'];self.clear();self.busy=True
        self.status.set('Capturando e analisando. Aguarde...')
        self.root.iconify()
        def worker():
            frame=None
            try:
                time.sleep(.7)
                frame, metadata=capture_window(hwnd)
                if metadata['window']['pid'] != selected['pid'] or metadata['window'].get('process_created') != selected.get('process_created'):
                    raise RuntimeError('Identidade da janela mudou. Atualize as janelas.')
                configure_tesseract()
                report=analyze_frame(frame,metadata)
                self.queue.put((frame,report))
            except Exception as exc:
                self.queue.put((frame,{'status':'ERROR','error':str(exc),'traceback':traceback.format_exc(),'actions_allowed':False,'hwnd':hwnd}))
        threading.Thread(target=worker,daemon=True).start()

    def poll(self):
        try:
            self.frame,self.report=self.queue.get_nowait();self.busy=False;self.root.deiconify()
            self.report.update(version=self.version,platform=platform.platform(),analyzed_at=time.time())
            lines=[]
            if 'error' in self.report:lines.append('ERRO: '+self.report['error'])
            canvas=self.frame.copy() if self.frame is not None else None
            for row in self.report.get('tables',[]):
                cards=[c.get('card_candidate') or '?' for c in row.get('reading',{}).get('hero_rank_candidates',[])]
                lines.append(f"Candidato {row['capture_index']}: {row['status']} | {' / '.join(cards) or 'Sem leitura'} | {row.get('reasons',[])} {row.get('error','')}")
                x,y,w,h=row['box']
                cv2.rectangle(canvas,(x,y),(x+w,y+h),(0,200,0) if len(cards)==2 and '?' not in cards else (0,0,255),2)
            if not lines:lines=['Nenhuma mesa completa reconhecida. Layout azul é o único calibrado. Salve o diagnóstico.']
            self.status.set('Falha na observação. Salve o diagnóstico.' if 'error' in self.report else 'Observação concluída. Resultado desta captura; não é estado ao vivo. Salve o diagnóstico.')
            self.details.configure(state='normal');self.details.insert('1.0','\n'.join(lines));self.details.configure(state='disabled')
            if canvas is not None:
                image=Image.fromarray(cv2.cvtColor(canvas,cv2.COLOR_BGR2RGB));image.thumbnail((950,410))
                self.photo=ImageTk.PhotoImage(image);self.preview.configure(image=self.photo)
        except queue.Empty:pass
        self.root.after(100,self.poll)

    def save(self):
        if self.busy:return
        if self.report is None:messagebox.showinfo('Diagnóstico','Atualize as janelas primeiro.');return
        try:
            path=export_diagnostic(self.report,self.frame,ROOT/'resultados',self.truth.get())
            messagebox.showinfo('Diagnóstico salvo',str(path)+'\nEnvie este ZIP para análise.')
        except Exception as exc:messagebox.showerror('Erro ao salvar',str(exc))


if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
