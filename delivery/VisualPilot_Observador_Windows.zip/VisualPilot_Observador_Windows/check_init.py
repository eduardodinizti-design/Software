import os
from pathlib import Path
import shutil
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'reader'))
import pytesseract

def configure_tesseract():
    candidates=[os.environ.get('TESSERACT_CMD'),shutil.which('tesseract')]
    for root in (os.environ.get('ProgramFiles'),os.environ.get('LOCALAPPDATA')):
        if root:
            candidates += [str(Path(root)/'Tesseract-OCR'/'tesseract.exe'),str(Path(root)/'Programs'/'Tesseract-OCR'/'tesseract.exe')]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            pytesseract.pytesseract.tesseract_cmd=candidate
            try:
                version=pytesseract.get_tesseract_version()
                if 'eng' not in pytesseract.get_languages(config=''):continue
                print('Tesseract OK:',version);return
            except Exception:continue
    raise RuntimeError('Tesseract nativo com idioma English nao encontrado. Baixe pelo link Windows em https://github.com/UB-Mannheim/tesseract/wiki . Instale e execute TESTAR_LEITURA.cmd novamente. Alternativa: defina TESSERACT_CMD com o caminho completo de tesseract.exe.')

if __name__=='__main__':
    try:
        import cv2,numpy,PIL,tkinter
        print('Python:',sys.version)
        from suit_reader import load_templates
        load_templates()
        print("Arquivos de naipes OK.")
        configure_tesseract()
        print('Dependencias OK. Teste somente de observacao.')
    except Exception as exc:
        print('FALHA:',exc);sys.exit(1)
