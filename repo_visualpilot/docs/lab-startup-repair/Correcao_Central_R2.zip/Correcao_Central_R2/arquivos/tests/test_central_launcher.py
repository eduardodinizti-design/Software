import unittest
from unittest.mock import patch, Mock
import sys
from types import ModuleType
from visualpilot.viz import launcher


class LauncherTests(unittest.TestCase):
    def test_browser_waits_for_health(self):
        response = Mock()
        response.__enter__ = Mock(return_value=Mock(status=200))
        response.__exit__ = Mock(return_value=False)
        opener = Mock(side_effect=[OSError('starting'), response])
        browser = Mock()
        with patch.object(launcher.time, 'sleep'):
            self.assertTrue(launcher.open_when_ready(opener=opener, browser=browser))
        browser.assert_called_once_with(launcher.PANEL_URL)

    def test_browser_does_not_open_on_timeout(self):
        browser = Mock()
        self.assertFalse(launcher.open_when_ready(timeout=0, browser=browser))
        browser.assert_not_called()

    def test_embedded_startup_without_stdin_or_valid_credentials(self):
        import json, os, socket, subprocess, tempfile, time
        from pathlib import Path
        from urllib.request import urlopen
        root=Path(__file__).resolve().parents[1]
        for credentials in (None, 'email = ""', '[general]\nemail = ""'):
            with self.subTest(credentials=credentials), tempfile.TemporaryDirectory() as folder:
                path=Path(folder);settings=path/'.streamlit';settings.mkdir()
                if credentials is not None:(settings/'credentials.toml').write_text(credentials)
                (settings/'config.toml').write_text('[server]\nheadless = false\nenableCORS = false\n')
                with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
                env=dict(os.environ,HOME=folder,USERPROFILE=folder,PYTHONPATH=str(root),VISUALPILOT_VALIDATE_STARTUP='test-token')
                code=f"import sys; sys.stdin=None; sys.stdout=None; sys.stderr=None; from visualpilot.viz import launcher; launcher.PANEL_URL='http://127.0.0.1:{port}'; launcher.main()"
                process=subprocess.Popen([sys.executable,'-c',code],cwd=folder,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                try:
                    ready=False
                    for _ in range(100):
                        if process.poll() is not None:break
                        try:
                            state=json.loads((path/'central_status.json').read_text())
                            if state['phase']=='ready':
                                with urlopen(f'http://127.0.0.1:{port}/_stcore/health',timeout=1) as response:ready=response.status==200
                                if ready:break
                        except (OSError,ValueError):pass
                        time.sleep(.1)
                    self.assertTrue(ready,(path/'central_startup.log').read_text() if (path/'central_startup.log').exists() else 'no log')
                    self.assertEqual(state['pid'],process.pid)
                    self.assertEqual(state['build'],launcher.BUILD_ID)
                    if credentials is not None:self.assertEqual((settings/'credentials.toml').read_text(),credentials)
                    self.assertNotIn('lost sys.stdin',(path/'central_startup.log').read_text())
                finally:
                    process.terminate()
                    try:process.wait(timeout=10)
                    except subprocess.TimeoutExpired:process.kill();process.wait()
