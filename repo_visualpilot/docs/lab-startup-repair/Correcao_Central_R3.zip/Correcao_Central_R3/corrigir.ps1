$ErrorActionPreference = 'Stop'
$projectRoot = 'C:\VisualPilot-entrega-visualpilot-piloto'
try {
    if (-not (Test-Path "$projectRoot\build_windows.ps1")) {
        throw "Pasta do projeto nao encontrada em $projectRoot. Execute esta correcao no PC principal."
    }
    $manifest = Get-Content "$PSScriptRoot\patch.json" -Raw | ConvertFrom-Json
    # Validate the entire patch before changing any source file.
    foreach ($entry in $manifest) {
        $source = Join-Path "$PSScriptRoot\arquivos" $entry.path
        if ((Get-FileHash $source -Algorithm SHA256).Hash.ToLower() -ne $entry.sha256) {
            throw "Arquivo da correcao incompleto: $($entry.path). Extraia o ZIP inteiro."
        }
    }
    $backup = Join-Path $projectRoot ('backup_codigo_' + (Get-Date -Format yyyyMMddHHmmss))
    foreach ($entry in $manifest) {
        $destination = Join-Path $projectRoot $entry.path
        if (Test-Path $destination) {
            $saved = Join-Path $backup $entry.path
            New-Item -ItemType Directory -Force -Path (Split-Path $saved) | Out-Null
            Copy-Item $destination $saved
        }
        New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
        Copy-Item (Join-Path "$PSScriptRoot\arquivos" $entry.path) $destination -Force
    }
    Write-Host 'Codigo atualizado. Preparando e testando a Central. Aguarde.'
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$projectRoot\build_windows.ps1"
    if ($LASTEXITCODE -ne 0) { throw 'A preparacao falhou. Nao copie programas para o notebook.' }
    Write-Host 'CONCLUIDO. Leve VisualPilot_Central_Corrigida.zip para o notebook e extraia em pasta nova.'
    Start-Process explorer.exe -ArgumentList "$projectRoot\dist"
} catch {
    Write-Host "ERRO: $($_.Exception.Message)"
    exit 1
}
