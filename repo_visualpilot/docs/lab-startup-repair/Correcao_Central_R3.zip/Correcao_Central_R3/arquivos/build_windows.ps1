$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    py -3.12 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw "Etapa falhou. Build interrompido." }
}
$python = ".venv\Scripts\python.exe"
# Preserve as configurações antes de o PyInstaller substituir dist.
$savedConfigs = @{}
foreach ($relative in @("VisualPilot_Coletor\stream_config.ini", "VisualPilot_Central\stream_config.ini", "VisualPilot_Central\nvt_config.ini")) {
    $path = Join-Path "dist" $relative
    if (Test-Path $path) { $savedConfigs[$relative] = [System.IO.File]::ReadAllBytes((Resolve-Path $path)) }
}
& $python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "Etapa falhou. Build interrompido." }
& $python -m pip install -e . -r requirements-build.txt
if ($LASTEXITCODE -ne 0) { throw "Etapa falhou. Build interrompido." }
& $python -m unittest discover -s tests
if ($LASTEXITCODE -ne 0) { throw "Etapa falhou. Build interrompido." }
& $python -m PyInstaller --clean --noconfirm build\VisualPilot_Coletor.spec
if ($LASTEXITCODE -ne 0) { throw "Etapa falhou. Build interrompido." }
& $python -m PyInstaller --clean --noconfirm build\VisualPilot_Central.spec
if ($LASTEXITCODE -ne 0) { throw "Etapa falhou. Build interrompido." }

Copy-Item stream_config.example.ini dist\VisualPilot_Coletor\stream_config.ini
Copy-Item stream_config.example.ini dist\VisualPilot_Central\stream_config.ini
Copy-Item nvt_config.example.ini dist\VisualPilot_Central\nvt_config.ini
foreach ($relative in $savedConfigs.Keys) {
    [System.IO.File]::WriteAllBytes((Join-Path "$PSScriptRoot\dist" $relative), $savedConfigs[$relative])
}
& $python tools\validate_distribution.py
if ($LASTEXITCODE -ne 0) { throw "Executavel nao passou no teste de inicializacao. Consulte o relatorio." }
& $python tools\seal_central_distribution.py
if ($LASTEXITCODE -ne 0) { throw "Falha ao preparar entrega para o notebook." }
Write-Host "Build concluído em dist\VisualPilot_Coletor e dist\VisualPilot_Central"
