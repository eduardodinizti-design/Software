"""Receptor asyncio: valida envelopes e entrega à Mailbox do runtime."""
import asyncio
import json
import struct
from time import monotonic

import cv2
import numpy as np

from .stream_node import MAX_PACKET


class StreamReceiver:
    def __init__(self, runtime, host='0.0.0.0', port=48735):
        self.runtime = runtime
        self.host, self.port = host, port
        self.sequences = {}
        self.clients = set()
        self.server = None
        self.members = {}
        self.retired_sessions = set()
        self.last_seen = {}
        self.identities = {}
        self.numbers = {}

    async def start(self):
        self.server = await asyncio.start_server(self.handle, self.host, self.port)
        return self.server.sockets[0].getsockname()

    async def close(self):
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        for writer in tuple(self.clients):
            writer.close()
            await writer.wait_closed()

    def accept_packet(self, packet):
        if not isinstance(packet, (bytes, bytearray)) or not 4 < len(packet) <= MAX_PACKET:
            raise ValueError('Pacote incompleto ou acima do limite')
        length = struct.unpack('!I', packet[:4])[0]
        if not 0 < length <= 4096 or length + 4 >= len(packet):
            raise ValueError('Cabeçalho inválido')
        header = json.loads(packet[4:4 + length])
        parts = [header[k] for k in ('member', 'session', 'table')]
        if any(not isinstance(p, str) or not 0 < len(p) <= 128 for p in parts):
            raise ValueError('Identidade inválida')
        key = json.dumps(parts, separators=(',', ':'))
        member, session, table = parts
        now = monotonic()
        if (member, session) in self.retired_sessions:
            return False
        previous = self.members.get(member)
        replacing = previous is not None and previous != session
        if replacing and now - self.last_seen[member] <= 5:
            return False  # Two running collectors must not fight for ownership.
        retired = [k for k, identity in self.identities.items()
                   if replacing and identity[0] == member]
        seq = header['sequence']
        if type(seq) is not int or seq <= 0:
            raise ValueError('Sequência inválida')
        if seq <= self.sequences.get(key, 0):
            return False
        if key not in self.sequences and len(self.sequences) - len(retired) >= 6:
            raise ValueError('Limite de seis mesas atingido')
        shape = header['shape']
        if len(shape) != 3 or not (0 < shape[0] <= 1800 and 0 < shape[1] <= 1200 and shape[2] == 3):
            raise ValueError('Dimensões inválidas')
        bgr = cv2.imdecode(np.frombuffer(packet[4 + length:], np.uint8), cv2.IMREAD_COLOR)
        if bgr is None or list(bgr.shape) != shape:
            raise ValueError('Imagem inválida')
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        membership_changed = key not in self.sequences
        if replacing:
            self.retired_sessions.add((member, previous))
        for old in retired:
            for mapping in (self.sequences, self.identities, self.numbers):
                mapping.pop(old, None)
        self.members[member] = session
        self.last_seen[member] = now
        self.identities[key] = (member, session, table)
        if key not in self.numbers:
            self.numbers[key] = next(n for n in range(1, 7) if n not in self.numbers.values())
        self.sequences[key] = seq
        if membership_changed:
            self.runtime.frames.retain(set(self.sequences))
            captures = getattr(self.runtime, 'captures', None)
            if captures is not None:
                from .multitable import latest
                latest(captures, dict(tables=[dict(table_key=k, number=self.numbers[k],
                                                 state='capturando') for k in self.sequences]))
        monitor = getattr(self.runtime, 'monitor', None)
        if monitor:
            monitor.retain(set(self.sequences))
            monitor.frame(key, self.numbers[key], rgb)
        self.runtime.frames.put(dict(table_key=key, number=self.numbers[key]), rgb)
        return True

    async def handle(self, reader, writer):
        self.clients.add(writer)
        try:
            while True:
                prefix = await asyncio.wait_for(reader.readexactly(4), 5)
                size = struct.unpack('!I', prefix)[0]
                if not 4 < size <= MAX_PACKET:
                    raise ValueError('Pacote inválido')
                packet = await asyncio.wait_for(reader.readexactly(size), 5)
                # Uma chamada por vez evita inversão de sequência e mantém a fila limitada.
                self.accept_packet(packet)
        except (asyncio.IncompleteReadError, TimeoutError, ValueError, KeyError, TypeError, OSError):
            pass
        finally:
            self.clients.discard(writer)
            writer.close()
            await writer.wait_closed()


async def run_remote_session(runtime, config_path='stream_config.ini'):
    """Inicia receptor e runtime juntos; runtime.stop encerra ambos."""
    import configparser
    config = configparser.ConfigParser()
    if not config.read(config_path):
        raise FileNotFoundError(config_path)
    receiver = StreamReceiver(runtime,
        config.get('central', 'listen_host', fallback='0.0.0.0'),
        config.getint('central', 'port'))
    await receiver.start()
    try:
        await asyncio.to_thread(runtime.run, capture=False)
    finally:
        runtime.stop.set()
        await receiver.close()
