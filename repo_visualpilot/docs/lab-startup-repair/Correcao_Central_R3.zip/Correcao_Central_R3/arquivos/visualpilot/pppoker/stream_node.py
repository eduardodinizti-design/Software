"""Transmissor TCP de recortes RGB; execute com python -m visualpilot.pppoker.stream_node."""
import configparser
import json
import socket
import struct
import sys
import threading
import uuid
from pathlib import Path
from queue import Queue

import cv2

MAX_PACKET = 8 * 1024 * 1024


def prepare_capture(rgb):
    """Reduz a janela inteira antes do transporte, preservando sua proporção."""
    if rgb.ndim != 3 or rgb.shape[2] != 3 or not rgb.size:
        raise ValueError('Captura RGB inválida')
    if rgb.shape[1] > 755:
        rgb = cv2.resize(rgb, (755, round(rgb.shape[0] * 755 / rgb.shape[1])),
                         interpolation=cv2.INTER_CUBIC)
    return rgb


def encode_frame(member, session, table, sequence, rgb):
    if rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.shape[0] > 1800 or rgb.shape[1] > 1200:
        raise ValueError('Dimensões inválidas')
    ok, data = cv2.imencode('.png', cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR),
                            [cv2.IMWRITE_PNG_COMPRESSION, 1])
    if not ok:
        raise ValueError('Falha ao codificar imagem')
    header = json.dumps(dict(member=member, session=session, table=table,
                             sequence=sequence, shape=list(rgb.shape))).encode()
    packet = struct.pack('!I', len(header)) + header + data.tobytes()
    if len(packet) > MAX_PACKET:
        raise ValueError('Frame excede limite')
    return struct.pack('!I', len(packet)) + packet


class FrameSender:
    def __init__(self, host, port, member):
        self.address = (host, port)
        self.member = member
        self.session = uuid.uuid4().hex
        self.sequence = {}
        self.socket = None

    def send(self, item, rgb, stamp=None):
        table = item['table_key']
        sequence = self.sequence.get(table, 0) + 1
        self.sequence[table] = sequence
        packet = encode_frame(self.member, self.session, table, sequence, prepare_capture(rgb))
        try:
            if self.socket is None:
                self.socket = socket.create_connection(self.address, timeout=1)
            self.socket.sendall(packet)
        except OSError:
            self.close()  # Próxima captura tenta reconectar; sem fila de frames antigos.

    def close(self):
        if self.socket is not None:
            self.socket.close()
            self.socket = None


def main():
    from visualpilot.pppoker.multitable import observe_tables
    root = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path.cwd()
    config = configparser.ConfigParser()
    if not config.read(root / 'stream_config.ini'):
        raise FileNotFoundError('stream_config.ini')
    sender = FrameSender(config['central']['host'], config.getint('central', 'port'),
                         config['member']['id'])
    stop = threading.Event()
    try:
        observe_tables(root / 'sessions', stop, Queue(1), frame_sink=sender.send,
                       max_tables=6, interval=.2)
    finally:
        stop.set()
        sender.close()


if __name__ == '__main__':
    main()
