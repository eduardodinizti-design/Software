"""Ponte assíncrona entre eventos de percepção e o Range Coach Pro."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy


class RangeCoachEventBridge:
    """Executa I/O de estratégia fora das threads críticas de OCR."""

    def __init__(self, strategy, result_sink=lambda event: None, workers=2):
        self.strategy = strategy
        self.result_sink = result_sink
        self.executor = ThreadPoolExecutor(max_workers=workers,
                                           thread_name_prefix="range-coach")

    def _done(self, source, identity, future):
        try:
            result = future.result()
        except Exception as exc:
            result = {"status": "error", "error": type(exc).__name__}
        self.result_sink(dict(kind="range_coach_result", source=source,
                              **identity, result=result))

    def partial_cards_ready(self, event, context=None):
        context = deepcopy(context or {})
        reading = deepcopy(event.get("reading") or {})
        identity = {key: event.get(key) for key in ("table", "generation")}
        future = self.executor.submit(self.strategy.theoretical_action,
                                      reading, context)
        future.add_done_callback(
            lambda completed: self._done("PARTIAL_CARDS_READY", identity, completed))
        return future

    def snapshot_consolidated(self, snapshot, context=None):
        context = deepcopy(context or {})
        tournament = context.get("tournament") or {}
        identity = {key: snapshot.get(key) for key in ("table", "hand_id")}
        future = self.executor.submit(self.strategy.audit_consolidated,
                                      deepcopy(snapshot), tournament)
        future.add_done_callback(
            lambda completed: self._done("SNAPSHOT_CONSOLIDATED", identity, completed))
        return future

    def close(self):
        self.executor.shutdown(wait=True, cancel_futures=True)
