"""Controle compartilhado da sessão remota, independente dos reruns do painel."""
import asyncio
from queue import Queue, Empty
import threading
from time import monotonic
from .monitor import LiveMonitor
from visualpilot.pppoker.observer.runtime import PerceptionSession
from visualpilot.pppoker.stream_receiver import run_remote_session


class RemoteSession:
    def __init__(self, root='sessions', config='stream_config.ini'):
        self.root, self.config = root, config
        self.thread = None
        self.stop = threading.Event()
        self.output = Queue(100)
        self.tables = {}
        self.error = None
        self.folder = None
        self.stale_after = 5.0
        self.monitor = LiveMonitor()

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.stop.clear()
        self.monitor = LiveMonitor()
        self.output = Queue(100)
        self.folder = None
        self.tables.clear()
        self.error = None
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        try:
            runtime = PerceptionSession(self.root, self.stop, self.output, monitor=self.monitor)
            asyncio.run(run_remote_session(runtime, self.config))
        except Exception as exc:
            self.error = str(exc)

    def poll(self):
        while True:
            try:
                event = self.output.get_nowait()
            except Empty:
                break
            if event.get('kind') in ('reading', 'partial_cards'):
                self.tables[event['table']] = dict(event, received_at=monotonic())
            if event.get('kind') == 'tables':
                active = {row['table_key'] for row in event['value']['tables']
                          if row['state'] == 'capturando'}
                self.tables = {key: value for key, value in self.tables.items() if key in active}
            if event.get('folder'):
                self.folder = event['folder']
            if event.get('error'):
                self.error = event['error']
        now = monotonic()
        for key, event in list(self.tables.items()):
            stamp = event.get('observed', event.get('received_at', now))
            age = max(0., now - stamp)
            event['age_seconds'] = age
            if age > self.stale_after and not event.get('stale'):
                # Keep the immutable historical record on disk, but never show
                # a disconnected table's old cards as a current observation.
                self.tables[key] = dict(event, stale=True, confirmed=False,
                    field_confirmation={}, reading=dict(status='pending',
                    reason='Sem leitura recente do coletor. Aguardando novas imagens.',
                    hero=[], board=[], street=None))
