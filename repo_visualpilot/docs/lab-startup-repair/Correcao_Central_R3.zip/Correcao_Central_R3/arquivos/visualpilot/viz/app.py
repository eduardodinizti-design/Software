"""Painel Streamlit da Central VisualPilot."""
from __future__ import annotations

from pathlib import Path

from visualpilot.agent.connector import RangeCoachConnector


def cloud_status(config_path="nvt_config.ini", connector_factory=RangeCoachConnector.from_ini):
    if not Path(config_path).is_file():
        return {"connected": False, "label": "⚪ Nuvem não configurada"}
    try:
        return connector_factory(config_path).diagnose()
    except Exception as exc:
        return {"connected": False, "label": "🔴 Configuração da nuvem inválida",
                "error": type(exc).__name__}


def render_cloud_diagnostic(st=None, config_path="nvt_config.ini"):
    """Pode ser chamado pelo app Streamlit sem tornar Streamlit uma dependência base."""
    if st is None:
        import streamlit as st
    status = cloud_status(config_path)
    st.subheader("Sincronização Range Coach Pro")
    st.write(status["label"])
    if status.get("latency_ms") is not None:
        st.caption(f"Latência do diagnóstico: {status['latency_ms']:.1f} ms")
    return status


def main():
    import streamlit as st
    st.set_page_config(page_title="NVT Poker Team — VisualPilot",
                       page_icon="♠", layout="wide")
    st.title("♠ NVT Poker Team")
    st.header("VisualPilot — Central de observação")
    st.caption("Projeto Piloto · mesas e fichas fictícias")
    from visualpilot.viz.launcher import BUILD_ID
    st.caption(f"Versão da Central: {BUILD_ID}")
    render_cloud_diagnostic(st)
    st.divider()
    from visualpilot.viz.session import RemoteSession
    @st.cache_resource
    def controller():
        return RemoteSession()
    session = controller()
    if st.button('Iniciar coleta'):
        session.start()
    if st.button('Parar coleta'):
        session.stop.set()
    @st.fragment(run_every=1)
    def readings():
        session.poll()
        active = session.thread is not None and session.thread.is_alive()
        st.write('Coleta ativa' if active else 'Coleta parada')
        if session.error:
            st.error(session.error)
        if session.folder:
            st.caption(f'Registros da sessão: {session.folder}')
        previews = session.monitor.snapshot()
        if session.monitor.error:
            st.warning(session.monitor.error)
        for key in dict.fromkeys([*session.tables, *previews]):
            event = session.tables.get(key, {})
            preview = previews.get(key, {})
            st.subheader(f"Mesa {event.get('number', preview.get('number', key))}")
            left, right = st.columns([1, 1])
            with left:
                if preview.get('preview'):
                    st.image(preview['preview'], caption='Imagem recebida da mesa · prévia amostrada', width='stretch')
                    st.caption(f"Imagem exibida há {preview['preview_age']:.1f} s · último frame recebido há {preview['frame_age']:.1f} s")
                    st.caption(f"Último recebimento (UTC): {preview.get('received_at')}")
                else:
                    st.info('Aguardando imagem para prévia.')
                if preview.get('frame_age') is not None and preview['frame_age'] > 5:
                    st.warning('Transmissão sem imagens recentes. A prévia acima está congelada.')
            with right:
                reading = event.get('reading', {})
                if event:
                    st.caption(f"Última leitura há {event.get('age_seconds', 0):.1f} s")
                    if event.get('stale'):
                        st.warning('Leitura desatualizada. Verifique se o coletor continua aberto no PC.')
                    if event.get('latency') is not None:
                        st.caption(f"Idade da amostra ao publicar a leitura: {event['latency']:.2f} s (não mede o tempo total de rede)")
                    st.write('Cartas do Hero: ' + (' · '.join(reading.get('hero') or []) or 'pendente'))
                    st.write('Board: ' + (' · '.join(reading.get('board') or []) or 'pendente / sem cartas reconhecidas'))
                    st.write('Etapa: ' + str(reading.get('street') or 'desconhecida'))
                    st.write(f"Pote: {reading.get('pot') or 'pendente'} · Stack: {reading.get('hero_stack') or 'pendente'}")
                    st.write('Botões e valores reconhecidos:')
                    buttons = reading.get('hero_buttons') or reading.get('actions') or []
                    labels = []
                    for button in buttons:
                        if isinstance(button, dict):
                            label = str(button.get('action', 'pendente')).title()
                            if button.get('amount') is not None:
                                label += f" {button['amount']} {button.get('unit') or ''}"
                            elif button.get('amount_status') == 'pending':
                                label += ' (valor pendente)'
                            labels.append(label)
                        else:
                            labels.append(str(button))
                    st.text(' · '.join(labels) or 'pendente / não observados')
                    st.write('Ações visíveis dos jogadores:')
                    actions = reading.get('observed_actions') or []
                    for action in actions:
                        st.text(f"{action.get('player_label') or 'jogador pendente'}: {action.get('action') or 'pendente'}" if isinstance(action, dict) else str(action))
                    if not actions: st.text('nenhuma reconhecida')
                    if reading.get('reason'): st.caption(reading['reason'])
                    with st.expander('Detalhes da leitura e qualidade'):
                        st.json(reading)
                        st.json(event.get('field_confirmation', {}))
                else:
                    st.info('Imagem recebida; aguardando reconhecimento.')
                if preview.get('button_seconds') is not None:
                    st.metric('Tempo desde a observação dos botões', f"{preview['button_seconds']:.1f} s")
                st.caption('Intervalos de botões são estimativas visuais. Não confirmam clique, ação escolhida ou motivo.')
                if st.button('Marcar decisão para revisão', key='mark-'+key):
                    session.monitor.mark(key)
                    preview = session.monitor.snapshot().get(key, preview)
                    st.success('Momento marcado no diário. Nenhuma jogada foi executada.')
                with st.expander('Momentos e evidências da mesa'):
                    st.caption('Imagens amostradas a cada 2 s nas leituras consolidadas, até 64 MB por sessão; não é gravação de vídeo contínua.')
                    events = preview.get('events', [])
                    st.caption('Até 30 eventos recentes. O histórico completo permanece na pasta da sessão.')
                    st.json(events)
                    import json
                    st.download_button('Baixar eventos recentes', json.dumps(events, ensure_ascii=False, indent=2),
                                       file_name='momentos.json', mime='application/json', key='download-'+key)
        if active and not session.tables and not previews:
            st.info('Aguardando imagens do coletor.')
    readings()


if __name__ == "__main__":
    main()
