"""Browser regression: pause, manual override, fresh automatic resumption."""
import argparse,json
from pathlib import Path
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();p.add_argument('--live-url',default='http://127.0.0.1:8767');p.add_argument('--replay-url',default='http://127.0.0.1:8766/VisualPilot_Laboratorio.html');p.add_argument('--output',default='docs/lab-handoff');args=p.parse_args()
out=Path(args.output);out.mkdir(parents=True,exist_ok=True);results=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    for name,url in [('replay',args.replay_url),('live',args.live_url)]:
        page=browser.new_page(viewport={'width':1440,'height':1050});errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(url);page.select_option('#speed','600');page.click('#play')
        page.wait_for_function('phase===3',timeout=30000);page.click('#play')
        page.wait_for_function("controlMode==='paused'&&!switching")
        page.wait_for_timeout(1600)
        assert page.evaluate("records.filter(r=>r.type==='action').length")==0
        page.click('#manual');page.wait_for_function("controlMode==='manual'&&phase===3&&!busy",timeout=30000)
        page.screenshot(path=str(out/f'{name}-manual.png'),full_page=True)
        page.click('[data-action=raise]')
        page.wait_for_function('phase===4&&!busy')
        action=page.evaluate("records.filter(r=>r.type==='action')[0].data")
        assert action['actor']=='human' and action['action']=='raise',action
        assert page.locator('[data-action=call]').is_disabled()
        page.click('#play');page.wait_for_function("records.filter(r=>r.type==='action').length>=2",timeout=30000)
        actions=page.evaluate("records.filter(r=>r.type==='action').map(r=>[r.data.actor,r.data.action])")
        assert actions[:2]==[['human','raise'],['engine','check']],actions
        page.wait_for_function('complete',timeout=45000)
        actions=page.evaluate("records.filter(r=>r.type==='action').map(r=>[r.data.actor,r.data.action])")
        assert actions==[['human','raise'],['engine','check'],['engine','bet'],['engine','raise'],['engine','fold']],actions
        with page.expect_download() as info:page.click('#download')
        info.value.save_as(str(out/f'{name}-session.json'))
        page.click('#reset');page.wait_for_function('!switching && phase===0');page.check('#obscure');page.click('#manual')
        page.wait_for_function("controlMode==='manual'&&phase===3&&!busy",timeout=30000)
        assert page.locator('#readHero').inner_text()=='Pendente'
        page.click('[data-action=fold]');page.wait_for_function('phase===4')
        assert page.evaluate("records.filter(r=>r.type==='action')[0].data.actor")=='human'
        page.set_viewport_size({'width':390,'height':844})
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
        assert not errors,errors
        results.append(dict(mode=name,actions=actions,pause_blocks=True,manual_with_hidden_hero=True,errors=errors))
        page.close()
    browser.close()
(out/'browser.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
