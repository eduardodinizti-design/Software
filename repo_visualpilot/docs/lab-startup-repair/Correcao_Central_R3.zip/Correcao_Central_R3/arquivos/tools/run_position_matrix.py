"""Broader board/range/position experiments with exact turn references."""
from pathlib import Path
import json,gzip,math
from dataclasses import replace
from visualpilot.agent.nvt_ranges import NvtRangeBook
from visualpilot.lab.scenario_matrix import BOARDS,CONTEXTS,make_case,condition_on_check
from visualpilot.lab.multistreet import SearchConfig,solve_postflop
from visualpilot.lab.opponent_models import size_sensitive_model


def run(case,model,config):
    return solve_postflop(case['hero'],case['board'],case['range'],case['pot'],case['stack'],model,
        'synthetic-size-sensitive-v1-aggression-.5',config,hero_position=case['hero_position'],
        opponent_checked=case['opponent_checked'])


def main():
    root=Path('docs/lab-position-matrix');root.mkdir(exist_ok=True)
    book=NvtRangeBook('tests/fixtures/nvt_position_excerpt.json')
    model=size_sensitive_model(.5);rows=[]
    # Fixed experiment design: six boards, five coherent seat/range contexts, three seeds.
    for context in CONTEXTS:
        for texture in BOARDS:
            config=SearchConfig(chance_method='stratified',chance_samples=6)
            case=condition_on_check(make_case(book,context,texture),model,config)
            reference=run(case,model,replace(config,exact_turn=True))
            assert reference['status']=='experimental' and reference['exact_under_model']
            exact=reference['comparisons'];best=max(exact.values())
            sampled=[run(case,model,replace(config,seed=s)) for s in (11,23,47)]
            stable=all(r['status']=='experimental' for r in sampled) and len({r.get('chosen') for r in sampled})==1
            record=dict(case={k:v for k,v in case.items() if k!='range'},reference=reference,sampled=sampled)
            name=case['id'].replace(':','-')
            (root/f'{name}.json.gz').write_bytes(gzip.compress(json.dumps(record,separators=(',',':')).encode(),mtime=0))
            row=dict(id=case['id'],position=case['hero_position'],range_node=case['provenance']['opponent']['node_id'],
                     combos=len(case['range']),exact_action=reference['chosen'],exact_ev=exact,
                     choices=[r.get('chosen') for r in sampled],seed_stable=stable,
                     regrets=[best-exact[r['chosen']] if r['status']=='experimental' else None for r in sampled],
                     rmse=[math.sqrt(sum((r['comparisons'][a]-v)**2 for a,v in exact.items())/len(exact))
                           if r['status']=='experimental' else None for r in sampled],
                     seconds=reference['seconds']+sum(r['seconds'] for r in sampled))
            rows.append(row);(root/'turn-summary.json').write_text(json.dumps(rows,indent=2))
            print(row['id'],row['exact_action'],row['choices'],round(row['seconds'],2),flush=True)
    # Flop checks use a smaller declared action grid and chance budget; no exact benchmark.
    flop=[]
    for context in ('BB_vs_BTN','BTN_vs_BB'):
        for texture in BOARDS:
            cfg=SearchConfig(fractions=(1/3,1.),chance_method='stratified',chance_samples=1,all_in_samples=200)
            case=condition_on_check(make_case(book,context,texture,'flop'),model,cfg)
            results=[run(case,model,replace(cfg,seed=s)) for s in (11,23,47)]
            flop.append(dict(id=case['id'],case={k:v for k,v in case.items() if k!='range'},results=results))
            print(case['id'],[r.get('chosen') for r in results],flush=True)
            (root/'flop-runs.json.gz').write_bytes(gzip.compress(json.dumps(flop,separators=(',',':')).encode(),mtime=0))
    regrets=[v for row in rows for v in row['regrets'] if v is not None]
    summary=dict(turn_scenarios=len(rows),exact_turn_searches=len(rows),approximate_turn_searches=len(rows)*3,
        flop_scenarios=len(flop),flop_searches=len(flop)*3,
        turn_decisions_within_003bb=sum(v<=.03 for v in regrets),turn_decisions=len(regrets),
        mean_regret_bb=sum(regrets)/len(regrets),worst_regret_bb=max(regrets),
        stable_turn_cases=sum(r['seed_stable'] for r in rows),
        stable_flop_cases=sum(len({r['chosen'] for r in c['results']})==1 for c in flop),
        limits=['one_Hero_hand_JTs','synthetic_opponent','no_GTO_validation','default_not_changed'])
    (root/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
