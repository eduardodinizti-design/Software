"""Publish conclusions only after all planned searches have finished."""
import gzip,json
from pathlib import Path

root=Path('docs/lab-exact-turn')
rows=json.loads((root/'summary.json').read_text())
assert len(rows)==6,'Experimentos ainda incompletos.'
before=json.loads((root/'before-optimization.json').read_text())
parity=[]
for old in before:
    new=next(r for r in rows if (r['scenario'],r['seed'])==(old['scenario'],old['seed']))
    assert new['status']==old['status']=='experimental'
    delta=max(abs(new['comparisons'][a]-v) for a,v in old['comparisons'].items())
    assert delta<1e-10,(new['scenario'],delta)
    parity.append(dict(scenario=new['scenario'],seed=new['seed'],max_ev_difference=delta,
                       before_seconds=old['seconds'],after_seconds=new['seconds']))
groups=[]
for scenario in ('turn_draw','flop_draw'):
    group=[r for r in rows if r['scenario']==scenario]
    complete=all(r['status']=='experimental' for r in group)
    stable=complete and len({r['chosen'] for r in group})==1
    means={a:sum(r['comparisons'][a] for r in group)/3 for a in group[0]['comparisons']} if complete else {}
    ordered=sorted(means.items(),key=lambda x:-x[1])
    groups.append(dict(scenario=scenario,status='experimental' if stable else 'pending',
        chosen=group[0]['chosen'] if stable else None,exact_under_model=all(r.get('exact_under_model') for r in group),
        mean_ev=means,top_gap=ordered[0][1]-ordered[1][1] if ordered else None,
        seconds=sum(r['seconds'] for r in group),reason='same_action_all_seeds' if stable else 'unstable_or_incomplete'))
report=dict(groups=groups,optimization_parity=parity,
    limitations=['synthetic_opponent_model','not_GTO','no_live_actions','flop_chance_still_sampled'])
(root/'conclusions.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
