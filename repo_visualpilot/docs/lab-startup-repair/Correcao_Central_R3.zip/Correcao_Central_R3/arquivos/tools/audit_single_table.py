"""Auditoria reproduzível de imagens disponíveis; ausências nunca viram aprovação.
Run: python -m tools.audit_single_table --output docs/lab-coverage
"""
import argparse
import hashlib
import json
from pathlib import Path
from time import perf_counter
import cv2
from visualpilot.pppoker.observer.perception import CachedReader, read_table
from visualpilot.pppoker.replay.reader import ReplayReader
from visualpilot.pppoker.card_reader import CardRegionReader
from visualpilot.pppoker.roi_engine import REGIONS

ROOT=Path(__file__).resolve().parents[1]

def card_coverage(results):
    coverage={rank+suit:dict(real_hero=[],real_board=[],synthetic_board_turn=[])
              for rank in '23456789TJQKA' for suit in 'shdc'}
    for result in results:
        if result['status']!='passed':continue
        if result.get('kind')=='synthetic':
            coverage[result['expected']]['synthetic_board_turn'].append(result['source'])
        elif result.get('kind')=='recorded':
            for field in ('hero','board'):
                for slot,card in enumerate(result['expected'][field]):
                    coverage[card]['real_'+field].append(dict(source=result['source'],slot=slot+1))
    return coverage

def run(output):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    reader=CachedReader(ReplayReader());cards=CardRegionReader(reader)
    fixtures=ROOT/'tests/fixtures';results=[]
    labels=json.loads((fixtures/'heldout_cards/labels.json').read_text())['cases']
    cases=[('heldout_cards/'+name+'.png',expected) for name,expected in labels.items()]
    cases += [('actions/right_99.png',dict(hero=['5c','2s'],board=[],actions=['Fold','Call 2,5 BB','Raise'],pot='Pot: 9,6 BB',hero_stack='102,6 BB')),
              ('actions/left_99.png',dict(hero=['Th','4d'],board=['7h','As','Ts'],street='flop',actions=[],pot='Pot: 4,0 BB',hero_stack='108,6 BB'))]
    for filename,expected in cases:
        path=fixtures/filename
        if not path.exists():
            results.append(dict(source=filename,status='missing',expected=expected));continue
        raw=path.read_bytes();image=cv2.cvtColor(cv2.imread(str(path)),cv2.COLOR_BGR2RGB)
        start=perf_counter();reading=read_table(reader,image)
        # OCR can omit spaces; compare text semantics without changing amounts.
        def comparable(value):
            if isinstance(value,str):return ''.join(value.split()).lower()
            if isinstance(value,list):return [comparable(v) for v in value]
            return value
        checks={key:comparable(reading.get(key))==comparable(value) for key,value in expected.items()}
        if expected['board']:
            checks['street']=reading.get('street')=={3:'flop',4:'turn',5:'river'}[len(expected['board'])]
        results.append(dict(source=str(path.relative_to(ROOT)),sha256=hashlib.sha256(raw).hexdigest(),
            kind='recorded',status='passed' if all(checks.values()) else 'failed',checks=checks,
            expected=expected,reading=reading,seconds=round(perf_counter()-start,4)))
    manifest=json.loads((fixtures/'synthetic_deck/manifest.json').read_text())
    for card in manifest['generated']:
        path=fixtures/'synthetic_deck'/f'{card}.png';image=cv2.cvtColor(cv2.imread(str(path)),cv2.COLOR_BGR2RGB)
        y,x,yy,xx=REGIONS['board_turn'][0];reading=cards.read_region('board_turn',image[y:yy,x:xx])
        passed=[r['card'] for r in reading['cards']]==[card]
        results.append(dict(source=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            kind='synthetic',region='board_turn',box_yxyx=[y,x,yy,xx],expected=card,
            status='passed' if passed else 'failed',reading=reading))
    summary={status:sum(r['status']==status for r in results) for status in ('passed','failed','missing')}
    report=dict(scope='recorded_images_and_synthetic_board_turn_only',summary=summary,results=results,
        card_coverage=card_coverage(results),
        unvalidated=['52 cartas reais em todas as posições','pré-flop visual positivo','botões Hero check/bet reais',
                     'todos os sizings','integração tracker real','Windows físico'])
    (output/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    lines=['# Auditoria por imagem','',str(summary),'','Fonte | Tipo | Resultado','--- | --- | ---']
    for r in results:
        source=ROOT/r['source'] if r['source'].startswith('tests/') else fixtures/r['source']
        import os
        link=os.path.relpath(source,output.resolve())
        lines.append(f"[{source.name}]({link}) | {r.get('kind','ausente')} | {r['status']}")
    (output/'index.md').write_text('\n'.join(lines)+'\n')
    rows=['# Cobertura por carta','',
          'Contagens são ocorrências nos casos aprovados, não garantias de acerto universal.',
          '', 'Carta | Hero real | Board real | Turn sintético','--- | --- | --- | ---']
    for card, evidence in report['card_coverage'].items():
        rows.append(f"{card} | {len(evidence['real_hero'])} | {len(evidence['real_board'])} | {len(evidence['synthetic_board_turn'])}")
    (output/'cards.md').write_text('\n'.join(rows)+'\n')
    print(json.dumps(summary));return report

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default='docs/lab-coverage')
    run(parser.parse_args().output)
