"""Refine uncertain draws; exact turn vs sampled turn, plus flop lookahead."""
import gzip,json
from pathlib import Path
from dataclasses import replace
from visualpilot.lab.multistreet import solve_postflop,SearchConfig
from visualpilot.lab.opponent_models import size_sensitive_model
from visualpilot.lab.postflop import range_from_nvt
from visualpilot.agent.nvt_ranges import NvtRangeBook


def main():
    root=Path('docs/lab-exact-turn');root.mkdir(exist_ok=True)
    book=NvtRangeBook('tests/fixtures/nvt_range_excerpt.json')
    node=next(n for n in book.nodes.values() if n['spot']=='open_raise')
    experiments=[]
    for name,board,pot,stack in [('turn_draw',['Kh','8h','2c','3d'],10,16),
                                ('flop_draw',['Kh','8h','2c'],6,18)]:
        weights,source=range_from_nvt(book,node['id'],'raise',['Ah','Jh']+board)
        for seed in (11,23,47):
            cfg=SearchConfig(chance_samples=3,exact_turn=True,seed=seed,max_nodes=250000)
            result=solve_postflop(['Ah','Jh'],board,weights,pot,stack,size_sensitive_model(.5),
                                 'synthetic-size-sensitive-v1-aggression-.5',cfg)
            record=dict(scenario=name,provenance=source,result=result)
            (root/f'{name}-{seed}.json.gz').write_bytes(gzip.compress(json.dumps(record,separators=(',',':')).encode(),mtime=0))
            summary=dict(scenario=name,seed=seed,status=result['status'],chosen=result.get('chosen'),
                seconds=result['seconds'],nodes=result['nodes'],exact_under_model=result.get('exact_under_model'),
                comparisons=result.get('comparisons'))
            experiments.append(summary)
            (root/'summary.json').write_text(json.dumps(experiments,indent=2))
            print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
