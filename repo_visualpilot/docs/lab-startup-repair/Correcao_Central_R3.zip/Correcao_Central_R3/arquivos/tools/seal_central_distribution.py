"""Create a separately named, complete notebook delivery after validation."""
import hashlib,json,zipfile
from pathlib import Path
from visualpilot.viz.launcher import BUILD_ID
root=Path(__file__).resolve().parents[1]
folder=root/'dist/VisualPilot_Central'
report=json.loads((root/'dist/startup-validation.json').read_text())
if report['status']!='passed':raise RuntimeError('Inicialização não validada.')
files={str(p.relative_to(folder)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()
       for p in sorted(folder.rglob('*')) if p.is_file() and p.suffix not in ('.log',) and p.name not in ('central_status.json','VERSAO_CENTRAL.json')}
(folder/'VERSAO_CENTRAL.json').write_text(json.dumps(dict(build=BUILD_ID,files=files),indent=2))
target=root/'dist/VisualPilot_Central_Corrigida.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix!='.log' and p.name!='central_status.json':
            z.write(p,'VisualPilot_Central_R2/'+str(p.relative_to(folder)).replace('\\','/'))
print('Pacote completo para o notebook:',target)
