"""Export a portable interactive REPLAY of actual OCR/policy executions."""
import argparse
import base64
import json
import cv2
import numpy as np
from pathlib import Path
from visualpilot.lab.engine import VisualLaboratory

def build(output,nvt_ranges=None):
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    if nvt_ranges:
        from visualpilot.lab.nvt_engine import NvtVisualLaboratory
        lab=NvtVisualLaboratory(nvt_ranges)
    else:lab=VisualLaboratory()
    data=dict(normal=[],blocked=[],metadata=getattr(lab,'metadata',{}))
    evidence=output.parent/'visual_lab_evidence';evidence.mkdir(exist_ok=True)
    for key,obscure in [('normal',False),('blocked',True)]:
        for index in range(5):
            event,png=lab.run(index,obscure)
            (evidence/f'{key}-{index}.png').write_bytes(png)
            (evidence/f'{key}-{index}.json').write_text(json.dumps(event,ensure_ascii=False,indent=2),encoding='utf-8')
            _,preview=cv2.imencode('.jpg',cv2.imdecode(np.frombuffer(png,np.uint8),cv2.IMREAD_COLOR),[cv2.IMWRITE_JPEG_QUALITY,82])
            event['image']='data:image/jpeg;base64,'+base64.b64encode(preview).decode()
            event['preview_note']='Compressed preview; SHA-256 identifies the original PNG in visual_lab_evidence.'
            data[key].append(event)
            if obscure:assert event['execution']['status']=='blocked',event
            elif nvt_ranges and index==3:assert event['execution']['status']=='blocked',event
            else:assert event['execution']['status']=='applied',event
            print(key,index,event['execution']['status'],flush=True)
    source=Path('visualpilot/lab/simulator.html').read_text(encoding='utf-8')
    source=source.replace('/*LAB_CONTROLLER*/',Path('visualpilot/lab/controller.js').read_text(encoding='utf-8'))
    payload=json.dumps(data,ensure_ascii=False).replace('</','<\\/')
    output.write_text(source.replace('/*LAB_DATA*/','window.LAB_DATA='+payload+';'),encoding='utf-8')
    print(output.resolve())

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default='dist/VisualPilot_Laboratorio.html')
    parser.add_argument('--nvt-ranges')
    args=parser.parse_args();build(args.output,args.nvt_ranges)
