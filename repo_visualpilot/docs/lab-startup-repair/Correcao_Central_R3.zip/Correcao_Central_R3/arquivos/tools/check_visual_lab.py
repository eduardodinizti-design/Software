import json
from pathlib import Path
from playwright.sync_api import sync_playwright
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--replay-url',default='http://127.0.0.1:8766/VisualPilot_Laboratorio.html')
parser.add_argument('--live-url',default='http://127.0.0.1:8765')
parser.add_argument('--output',default='docs/lab-visual/browser-artifacts')
args=parser.parse_args();out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
results=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1050},device_scale_factor=1)
    errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto(args.replay_url)
    page.select_option('#speed','600');page.click('#play')
    page.wait_for_function('complete',timeout=45000)
    page.screenshot(path=str(out/'simulator.png'),full_page=True)
    assert page.locator('#readHero').inner_text()=='5c · 2s'
    page.click('#evidence');assert page.locator('#dialog').is_visible();page.click('#close')
    actions=page.evaluate("records.filter(r=>r.type==='action').map(r=>r.data.action)")
    assert actions==['call','check','bet','raise','fold'],actions
    assert page.locator('#hero').get_attribute('class')=='hero folded'
    with page.expect_download() as download:page.click('#download')
    download.value.save_as(str(out/'session.json'))
    results.append({'mode':'offline_replay','actions':actions,'download':'ok','evidence_dialog':'ok'})
    page.click('#reset');page.check('#obscure');page.click('#play')
    page.wait_for_function('phase===4',timeout=20000)
    assert page.locator('#choice').inner_text()=='AÇÃO BLOQUEADA'
    assert page.evaluate("records.filter(r=>r.type==='action').length")==0
    page.click('#play')
    results.append({'mode':'offline_occlusion','blocked':True})
    page.goto(args.live_url);page.click('#reset');page.wait_for_function('!switching');page.select_option('#speed','600');page.click('#play')
    page.wait_for_function('phase===4',timeout=45000);page.click('#play');page.wait_for_function('!switching')
    assert page.evaluate("records.filter(r=>r.type==='action').map(r=>r.data.action)")==['call']
    results.append({'mode':'live_ocr_http','action':'call','recorded':True})
    page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(out/'mobile.png'),full_page=True)
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
    assert not errors,errors
    results.append({'browser_errors':errors,'mobile_horizontal_overflow':False})
    browser.close()
(out/'browser.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results))
