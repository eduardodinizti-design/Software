"""Exhaustive 5-card parity plus reproducible 7-card parity and CPU benchmark."""
from itertools import combinations
from collections import Counter
import json,random,time
from pathlib import Path
from visualpilot.lab.hand_rank import rank_hand
from visualpilot.lab.postflop import DECK,rank5,rank7

start=time.perf_counter();counts=Counter();checked=0
for cards in combinations(DECK,5):
    expected=rank5(cards);actual=rank_hand(cards)
    if actual!=expected: raise AssertionError((cards,actual,expected))
    counts[actual[0]]+=1;checked+=1
rng=random.Random(2931);hands=[rng.sample(DECK,7) for _ in range(10000)]
start_cpu=time.process_time();expected=[rank7(h) for h in hands];old_cpu=time.process_time()-start_cpu
start_cpu=time.process_time();actual=[rank_hand(h) for h in hands];new_cpu=time.process_time()-start_cpu
assert actual==expected
report=dict(five_card_hands=checked,categories=dict(counts),seven_card_hands=len(hands),passed=True,
            old_rank7_cpu_seconds=old_cpu,new_rank7_cpu_seconds=new_cpu,
            cpu_speedup=old_cpu/new_cpu,total_seconds=time.perf_counter()-start)
Path('docs/lab-exact-turn/evaluator-audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
