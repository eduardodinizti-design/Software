"""Portable evidence viewer; displays precomputed experiments, not a live solver."""
import json
import gzip
from pathlib import Path


def simplified(solution):
    return dict(chosen=solution['chosen'],ev=solution['ev'],sha256=solution['sha256'],
                decisions=[dict(history=n['history'],alternatives=n['alternatives'],chosen=n['chosen'],
                    combo_count=len(n['range']),top_combos=sorted(n['range'],key=lambda c:-c[2])[:8])
                    for n in solution['decisions']])


def main():
    root=Path('docs/lab-postflop-tree')
    source=json.loads(gzip.decompress((root/'experiments.json.gz').read_bytes()))
    data=[]
    for e in source['experiments']:
        data.append(dict(profile=e['profile'],solution=simplified(e['solution']),
            events=e['range_state']['events'],source=e['range_state']['provenance'],
            rivers=[dict(card=b['card'],probability=b['probability'],solution=simplified(b['solution']))
                    for b in (e['lookahead'] or {}).get('branches',[])]))
    html='''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>VisualPilot — Experimentos pós-flop</title><style>
*{box-sizing:border-box}body{margin:0;background:#0d1720;color:#e2edf1;font:16px system-ui;line-height:1.5}main{max-width:1100px;margin:auto;padding:24px}h1{font-size:30px}h2{font-size:21px}small,.muted{color:#acbcc5}section{background:#152630;padding:22px;border-radius:12px;margin:18px 0}select,button{font:inherit;background:#233c49;color:white;border:1px solid #68808d;border-radius:6px;padding:10px;max-width:100%}button{cursor:pointer}.table{background:#123e35;border:5px solid #477568;border-radius:70px;padding:28px;text-align:center}.cards{font-size:25px;letter-spacing:3px}.row{display:flex;gap:14px;flex-wrap:wrap}.row>*{flex:1;min-width:220px}.badge{color:#88e5bb}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:10px;border-bottom:1px solid #3b535d}.best{color:#8ee8b9}code{overflow-wrap:anywhere}.note{border-left:4px solid #e3b96b;padding:12px}#rootEv{font-size:26px}label{display:block;margin:8px 0}details{margin-top:15px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px}@media(max-width:500px){main{padding:12px}.table{border-radius:25px;padding:14px}td,th{padding:6px}}
</style><main><p class="badge">VISUALPILOT · LABORATÓRIO</p><h1>A engine comparando decisões no pós-flop</h1>
<p>Resultados calculados automaticamente. Este arquivo permite inspecionar os experimentos; não executa novas simulações nem controla mesas.</p>
<p class="note">Adversários sintéticos, com comportamento definido para testes. Melhor decisão <b>sob esse modelo</b>, sem alegação de GTO ou rentabilidade real. Range inicial: open-raise BTN do pacote NVT.</p>
<section class="table"><p>Hero no BB · adversário BTN · 2 jogadores</p><div class="cards">Hero: A♥ J♥</div><p id="board" class="cards"></p><p>Início do river: pote 10 BB · Stack efetivo disponível: 18 BB</p><small>Linha controlada: flop check / bet 2 / call 2; turn check / check.</small></section>
<section><div class="row"><div><label for="profile">Perfil experimental</label><select id="profile"></select></div><div><label for="river">River analisado</label><select id="river"></select></div></div><p><button id="play">Percorrer os 5 perfis</button></p><div id="rootEv"></div><small>EV incremental a partir do início do river, em BB. Comparação exata dentro da árvore e do modelo.</small></section>
<section><h2>Decisão em cada caminho da mão</h2><label for="node">Histórico público antes da decisão do Hero</label><select id="node"></select><table><thead><tr><th>Ação do Hero</th><th>EV (BB)</th><th>Escolha calculada</th></tr></thead><tbody id="actions"></tbody></table><p id="rangeCount"></p><details><summary>Combinações adversárias mais prováveis neste caminho</summary><pre id="combos"></pre></details></section>
<section><h2>O que foi considerado</h2><p>Bloqueadores, atualização do range por ações, apostas de 3 e 7 BB, raises para 14 e 18 BB, fold, call e check. Um raise por linha; sem re-raise, rake ou ICM.</p><p>O perfil intermediário também contém todos os rivers possíveis após o turn. A seleção de river mostra um novo plano condicionado à carta. Isso ainda não escolhe apostas no turn.</p><details><summary>Rastreabilidade do cálculo</summary><pre id="audit"></pre></details></section></main><script>
const DATA=__DATA__;const $=id=>document.getElementById(id);let solution,timer;
const card=c=>c[0]+({c:'♣',d:'♦',h:'♥',s:'♠'}[c[1]]||c[1]);
const action=a=>a.replace('check','Check').replace('fold','Fold').replace('call','Call').replace('bet:','Apostar ').replace('raise:','Raise para ');
DATA.forEach((e,i)=>$('profile').add(new Option('Perfil '+(i+1)+' · agressividade '+e.profile.split('-').pop(),i)));
function profile(){const e=DATA[+$('profile').value];$('river').replaceChildren(new Option('River original · 9♠','original'));e.rivers.forEach(b=>$('river').add(new Option(card(b.card)+' · prob. '+(b.probability*100).toFixed(2)+'%',b.card)));render()}
function render(){const e=DATA[+$('profile').value],r=e.rivers.find(b=>b.card===$('river').value);solution=r?r.solution:e.solution;$('board').textContent='K♥ 8♥ 2♣ 3♦ '+(r?card(r.card):'9♠');$('rootEv').textContent=action(solution.chosen)+' · EV '+solution.ev.toFixed(3)+' BB';$('node').replaceChildren();solution.decisions.forEach((n,i)=>$('node').add(new Option(n.history.length?n.history.map((a,i)=>(i%2?'Adversário: ':'Hero: ')+action(a)).join(' → '):'Início do river',i)));$('node').value=solution.decisions.length-1;$('audit').textContent=JSON.stringify({profile:e.profile,source:e.source,hash:solution.sha256,range_updates:e.events},null,2);node()}
function node(){const n=solution.decisions[+$('node').value];$('actions').replaceChildren();Object.entries(n.alternatives).sort((a,b)=>b[1]-a[1]).forEach(([a,ev])=>{const tr=document.createElement('tr');[action(a),ev.toFixed(3),a===n.chosen?'Selecionada':''].forEach(t=>{const td=document.createElement('td');td.textContent=t;tr.append(td)});if(a===n.chosen)tr.className='best';$('actions').append(tr)});$('rangeCount').textContent=n.combo_count+' combinações possíveis neste caminho; a engine não conhece a mão escondida.';$('combos').textContent=n.top_combos.map(c=>c[0]+' '+c[1]+' : '+(c[2]*100).toFixed(2)+'%').join('\n')}
$('profile').onchange=profile;$('river').onchange=render;$('node').onchange=node;$('play').onclick=()=>{if(timer){clearInterval(timer);timer=null;$('play').textContent='Percorrer os 5 perfis';return}let i=0;$('profile').value=i;profile();$('play').textContent='Pausar';timer=setInterval(()=>{i++;if(i>=DATA.length){clearInterval(timer);timer=null;$('play').textContent='Percorrer os 5 perfis';return}$('profile').value=i;profile()},1600)};profile();
</script></html>'''
    html=html.replace('__DATA__',json.dumps(data,ensure_ascii=False).replace('</','<\\/'))
    # The JavaScript newline literal must remain escaped inside the embedded script.
    html=html.replace(".join('\n')", ".join('\\n')")
    out=Path('/workspace/entrega/VisualPilot_Posflop_Experimentos.html')
    out.write_text(html,encoding='utf-8')
    print(out)

if __name__=='__main__':main()
