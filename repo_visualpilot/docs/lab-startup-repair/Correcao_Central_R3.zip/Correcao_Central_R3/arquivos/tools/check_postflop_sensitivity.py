"""Change synthetic opponent assumptions after removing turn sampling noise."""
import gzip,json
from pathlib import Path
from visualpilot.lab.multistreet import SearchConfig,solve_postflop
from visualpilot.lab.opponent_models import size_sensitive_model

root=Path('docs/lab-exact-turn')
base=json.loads(gzip.decompress((root/'turn_draw-11.json.gz').read_bytes()))['result']['inputs']
weights={(a,b):w for a,b,w in base['weights']}
results=[]
for aggression in (.25,.75):
    result=solve_postflop(base['hero'],base['board'],weights,base['pot'],base['stack'],
        size_sensitive_model(aggression),f'synthetic-size-sensitive-v1-aggression-{aggression}',
        SearchConfig(exact_turn=True,max_nodes=250000))
    results.append(dict(aggression=aggression,result=result))
    print(aggression,result['chosen'],result['comparisons'],flush=True)
(root/'model-sensitivity.json.gz').write_bytes(gzip.compress(json.dumps(results,separators=(',',':')).encode(),mtime=0))
