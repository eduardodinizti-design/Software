"""Verify NVT ranges, human grading, blocked raises and traceability in Chromium."""
import argparse,json
from pathlib import Path
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();p.add_argument('--replay-url',default='http://127.0.0.1:8771/VisualPilot_Preflop_NVT.html');p.add_argument('--live-url',default='http://127.0.0.1:8770');p.add_argument('--output',default='docs/lab-nvt-integration');args=p.parse_args();out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
results=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    for mode,url in [('replay',args.replay_url),('live',args.live_url)]:
        page=browser.new_page(viewport={'width':1440,'height':1200});errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(url);page.click('#reset');page.wait_for_function('!switching');page.select_option('#speed','600');page.click('#play')
        page.wait_for_function('index===2 && phase===2',timeout=45000)
        page.click('#manual');page.wait_for_function("controlMode==='manual' && phase===3 && !busy",timeout=30000)
        assert page.locator('#rangeMix').inner_text().count('50%')==2
        assert 'chip_ev|mid|25|vs_open|BB|BTN|-' in page.locator('#rangeNode').inner_text()
        assert page.locator('#nvtSeats > div').count()==8
        page.select_option('#rangeAnswer','call');page.click('#evaluate');page.wait_for_function('!busy')
        assert 'aceita' in page.locator('#grade').inner_text()
        page.screenshot(path=str(out/f'{mode}-nvt.png'),full_page=True)
        page.click('[data-action=call]');page.wait_for_function('phase===4 && !busy')
        page.click('#play');page.wait_for_function('index===3 && phase===3',timeout=30000)
        page.click('#manual');page.wait_for_function("controlMode==='manual' && phase===3 && !busy",timeout=30000)
        assert 'Raise 100%' in page.locator('#rangeMix').inner_text()
        assert page.locator('[data-action=raise]').count()==0
        page.select_option('#rangeAnswer','raise');page.click('#evaluate');page.wait_for_function('!busy')
        assert 'aceita' in page.locator('#grade').inner_text()
        assert page.evaluate("records.filter(r=>r.type==='action'&&r.data.action==='raise').length")==0
        page.click('#play');page.wait_for_function('complete',timeout=30000)
        actions=page.evaluate("records.filter(r=>r.type==='action').map(r=>[r.data.actor,r.data.action])")
        assert actions==[['engine','fold'],['engine','call'],['human','call'],['engine','check']],actions
        with page.expect_download() as d:page.click('#download')
        d.value.save_as(str(out/f'{mode}-session.json'))
        page.set_viewport_size({'width':390,'height':844})
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
        assert not errors,errors
        results.append(dict(mode=mode,mix_display=True,manual_grade=True,unsized_raise_not_executed=True,actions=actions,errors=errors))
        page.close()
    browser.close()
(out/'browser.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
