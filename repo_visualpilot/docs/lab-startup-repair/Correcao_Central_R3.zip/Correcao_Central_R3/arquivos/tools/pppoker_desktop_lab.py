"""Laboratório visual com seis janelas; requer um display gráfico disponível."""
from __future__ import annotations

import argparse
import json
import statistics
import threading
import time
from pathlib import Path
from queue import Empty, Queue

from PIL import Image, ImageTk
import tkinter as tk

from visualpilot.pppoker.observer.runtime import PerceptionSession


ROOT = Path(__file__).resolve().parents[1]
SOURCES = [ROOT / "tests/fixtures/actions/left_99.png",
           ROOT / "tests/fixtures/actions/right_99.png"]
EXPECTED = [
    {
        "hero": ["Th", "4d"],
        "board": ["7h", "As", "Ts"],
        "street": "flop",
        "hand_id": "261023232509-13536175-0000157-5",
        "hero_buttons": [],
        "visible_actions": {("vitriago", "check"), ("rossykind4", "fold"),
                            ("SDekus", "fold"), ("KKingJJam..", "fold")},
    },
    {
        "hero": ["5c", "2s"],
        "board": [],
        "street": None,
        "hand_id": "261024093320-13552339-0000050-2",
        "hero_buttons": ["Fold", "Call2,5BB", "Raise"],
        "visible_actions": {("Jhavidpino", "call"), ("Chow Mein...", "fold"),
                            ("smilekilla", "raise"), ("Mihcardoso7", "fold"),
                            ("KenLy", "call")},
    },
]


def action_pairs(reading):
    return {(item.get("player_label"), item.get("action"))
            for item in reading.get("observed_actions", [])}


def matches(reading, expected):
    return {
        "hero": reading.get("hero") == expected["hero"],
        "board": reading.get("board") == expected["board"],
        "street": reading.get("street") == expected["street"],
        "hand_id": reading.get("hand_id") == expected["hand_id"],
        "hero_buttons": reading.get("actions") == expected["hero_buttons"],
        "visible_actions": action_pairs(reading) == expected["visible_actions"],
    }


def card_matches(reading, expected):
    return (reading.get("hero") == expected["hero"] and
            reading.get("board") == expected["board"] and
            reading.get("street") == expected["street"])


def storage_integrity(session_path):
    result = {"json_files_valid": False, "journal_records": 0,
              "saved_evidence_references": 0, "missing_or_invalid_evidence": []}
    if not session_path:
        return result
    try:
        json.loads((session_path / "session.json").read_text(encoding="utf-8"))
        json.loads((session_path / "metricas.json").read_text(encoding="utf-8"))
        records = [json.loads(line) for line in
                   (session_path / "percepcao.jsonl").read_text(encoding="utf-8").splitlines()
                   if line.strip()]
        result["json_files_valid"] = True
        result["journal_records"] = len(records)
        for record in records:
            evidence = record.get("visual_evidence", {})
            path = evidence.get("path")
            if evidence.get("status") != "saved" or not path:
                continue
            result["saved_evidence_references"] += 1
            target = session_path / path
            try:
                with Image.open(target) as image:
                    image.verify()
            except Exception as exc:
                result["missing_or_invalid_evidence"].append({"path": path, "error": str(exc)})
    except Exception as exc:
        result["error"] = str(exc)
    result["passed"] = (result["json_files_valid"] and result["journal_records"] > 0
                        and result["saved_evidence_references"] > 0
                        and not result["missing_or_invalid_evidence"])
    return result


class SixTableDesktop:
    def __init__(self, root, width=835, height=1485):
        self.root = root
        self.width, self.height = width, height
        self.originals = [Image.open(path).convert("RGB").resize((width, height), Image.Resampling.LANCZOS)
                          for path in SOURCES]
        self.photos = [ImageTk.PhotoImage(image) for image in self.originals]
        self.windows = []
        self.labels = []
        root.withdraw()
        for index in range(6):
            window = tk.Toplevel(root)
            window.overrideredirect(True)
            x, y = (index % 3) * width, (index // 3) * height
            window.geometry(f"{width}x{height}+{x}+{y}")
            label = tk.Label(window, borderwidth=0, highlightthickness=0)
            label.pack(fill="both", expand=True)
            self.windows.append(window)
            self.labels.append(label)
        self.show_phase(0)
        root.update_idletasks()
        root.update()

    def source_for(self, slot, phase):
        return (slot + phase) % 2

    def show_phase(self, phase):
        for slot, label in enumerate(self.labels):
            label.configure(image=self.photos[self.source_for(slot, phase)])
        self.root.update_idletasks()
        self.root.update()

    def native_windows(self):
        screen_width = self.root.winfo_screenwidth()
        result = []
        for slot in range(6):
            left = (slot % 3) * self.width
            result.append({
                "pid": 10000 + slot,
                "handle": 20000 + slot,
                "title": f"PPPoker LAB {slot + 1}",
                "box": [left, (slot // 3) * self.height,
                        min(self.width, screen_width - left), self.height],
            })
        return result

    def close(self):
        for window in self.windows:
            window.destroy()


def table_slot(item, width=835, height=1485):
    x, y, _, _ = item.get("capture_box", item["box"])
    return max(0, min(5, round(y / height) * 3 + round(x / width)))


def run(output, phase_timeout=75.0, cycles=6):
    root = tk.Tk()
    desktop = SixTableDesktop(root)
    stop = threading.Event()
    events = Queue(256)
    session = PerceptionSession(output, stop, events, workers=2,
                                windows_reader=desktop.native_windows)
    worker = threading.Thread(target=session.run, name="pppoker-lab-session", daemon=False)
    worker.start()
    began = time.monotonic()
    phase = 0
    phase_started = began
    mappings = {}
    discovery_seconds = None
    readings = [{} for _ in range(cycles)]
    confirmation = [{} for _ in range(cycles)]
    partial_cards = [{} for _ in range(cycles)]
    wrong_table_readings = []
    folder = None
    finished = None
    try:
        while time.monotonic() - began < phase_timeout * cycles + 20:
            root.update()
            now = time.monotonic()
            for _ in range(256):
                try:
                    event = events.get_nowait()
                except Empty:
                    break
                if event["kind"] == "started":
                    folder = event["folder"]
                elif event["kind"] == "tables":
                    active = [item for item in event["value"]["tables"] if item["state"] == "capturando"]
                    if len(active) == 6 and discovery_seconds is None:
                        discovery_seconds = now - began
                    for item in active:
                        mappings[item["table_key"]] = table_slot(item)
                elif event["kind"] == "reading":
                    slot = mappings.get(event["table"])
                    if slot is None:
                        continue
                    expected_index = desktop.source_for(slot, phase)
                    checks = matches(event["reading"], EXPECTED[expected_index])
                    opposite_checks = matches(event["reading"], EXPECTED[1 - expected_index])
                    # Events captured before the visual swap may still be queued.
                    # They are historical samples, not cross-table contamination.
                    if event["observed"] >= phase_started and all(opposite_checks.values()):
                        wrong_table_readings.append({"phase": phase, "slot": slot,
                                                     "seconds": now - phase_started})
                    if all(checks.values()):
                        readings[phase].setdefault(slot, {
                            "seconds": now - phase_started,
                            "capture_age_seconds": event["latency"],
                            "checks": checks,
                            "cached": event["cached"],
                        })
                        if event["field_confirmation"]["hero"]["confirmed"]:
                            confirmation[phase].setdefault(slot, now - phase_started)
                elif event["kind"] == "partial_cards":
                    slot = mappings.get(event["table"])
                    if slot is None:
                        continue
                    expected_index = desktop.source_for(slot, phase)
                    if card_matches(event["reading"], EXPECTED[expected_index]):
                        partial_cards[phase].setdefault(slot, {
                            "seconds": now - phase_started,
                            "capture_age_seconds": event["latency"],
                            "generation": event["generation"],
                        })
                elif event["kind"] == "finished":
                    finished = event
            if len(readings[phase]) == 6 and len(confirmation[phase]) == 6:
                if phase + 1 == cycles:
                    break
                phase += 1
                desktop.show_phase(phase)
                phase_started = time.monotonic()
            elif now - phase_started > phase_timeout:
                break
            time.sleep(.02)
    finally:
        stop.set()
        worker.join(25)
        desktop.close()
        root.destroy()
        while not events.empty():
            event = events.get_nowait()
            if event.get("kind") == "finished":
                finished = event
    if worker.is_alive():
        raise RuntimeError("A coleta não encerrou no prazo")
    session_path = Path(folder) if folder else None
    report = {
        "scope": "Seis janelas reais em um display virtual Linux; mesmo motor de descoberta, captura, OCR, confirmação e armazenamento. Não equivale a dois monitores Windows.",
        "sources": [str(path.relative_to(ROOT)) for path in SOURCES],
        "displayed_table_size": [desktop.width, desktop.height],
        "discovery_seconds": discovery_seconds,
        "cycles_requested": cycles,
        "phases": [dict(
            name="initial" if index == 0 else f"simultaneous_change_{index}",
            fully_read_tables=len(readings[index]),
            hero_confirmed_tables=len(confirmation[index]),
            all_read_seconds=max((item["seconds"] for item in readings[index].values()), default=None),
            all_confirmed_seconds=max(confirmation[index].values(), default=None),
            partial_card_tables=len(partial_cards[index]),
            all_partial_cards_seconds=max((item["seconds"] for item in partial_cards[index].values()), default=None),
            partial_cards=partial_cards[index],
            tables=readings[index]) for index in range(cycles)],
        "wrong_table_readings": wrong_table_readings,
        "session_folder": str(session_path) if session_path else None,
        "session_files": {
            name: bool(session_path and (session_path / name).is_file())
            for name in ("session.json", "percepcao.jsonl", "metricas.json")
        },
        "evidence_images": len(list((session_path / "evidencias").glob("*.png")))
                           if session_path and (session_path / "evidencias").is_dir() else 0,
        "runtime_error": finished.get("error") if finished else "evento final ausente",
        "metrics": finished.get("metrics") if finished else None,
        "storage_integrity": storage_integrity(session_path),
    }
    report["passed"] = (
        discovery_seconds is not None
        and all(item["fully_read_tables"] == 6 and item["hero_confirmed_tables"] == 6
                and item["partial_card_tables"] == 6
                for item in report["phases"])
        and all(report["session_files"].values())
        and report["evidence_images"] > 0
        and report["runtime_error"] is None
        and not wrong_table_readings
        and report["storage_integrity"].get("passed", False)
    )
    completed = [phase["all_read_seconds"] for phase in report["phases"]
                 if phase["all_read_seconds"] is not None]
    report["performance"] = {
        "completed_cycles": len(completed),
        "median_all_tables_seconds": statistics.median(completed) if completed else None,
        "maximum_all_tables_seconds": max(completed) if completed else None,
        "maximum_change_seconds": max(completed[1:] or completed) if completed else None,
        "target_all_tables_seconds": 15.0,
        "within_current_target": bool(completed) and max(completed[1:] or completed) <= 15.0,
    }
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="sessions/lab")
    parser.add_argument("--report", default="docs/pppoker-desktop-lab.json")
    parser.add_argument("--phase-timeout", type=float, default=75.0)
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()
    if args.cycles < 2:
        parser.error("Use pelo menos dois ciclos")
    report = run(args.output, args.phase_timeout, args.cycles)
    target = Path(args.report)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
