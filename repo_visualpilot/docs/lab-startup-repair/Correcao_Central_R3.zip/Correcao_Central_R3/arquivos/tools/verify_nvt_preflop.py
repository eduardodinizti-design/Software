"""Exhaustive parity of every exported preflop hand mix, against the actual package."""
import argparse,json
from pathlib import Path
from visualpilot.agent.nvt_ranges import NvtRangeBook

def cards(hand):
    return [hand[0]+'h',hand[1]+('h' if hand.endswith('s') else 'd')]

def run(path,output):
    source=json.loads(Path(path).read_text());book=NvtRangeBook(path)
    passed=0;excluded=0;failures=[];checked=0;failed=0
    for node in source['nodes']:
        if not node['validated']:continue
        context=dict(node['context'],position=node['hero'],spot=node['spot'],vs=node['vs'],spread=node.get('spread'))
        for i,hand in enumerate(source['hands']):
            checked+=1
            result=book.recommend(dict(hero=cards(hand),board=[],street='preflop'),context)
            if i in node.get('outOfRange',[]):
                ok=result['status']=='out_of_range';excluded+=1
            else:
                expected=sorted([dict(action=a,frequency=node['freq'][a][i]) for a in node['actions'] if node['freq'][a][i]>0],key=lambda x:-x['frequency'])
                ok=result.get('mix')==expected
            if ok:passed+=1
            else:
                failed+=1
                if len(failures)<10:failures.append(dict(node=node['id'],hand=hand,result=result))
    report=dict(provenance=book.provenance,nodes=len(book.nodes),hand_queries=checked,
                passed=passed,failed=failed,failures=failures,out_of_range_queries=excluded,
                scope='Exact exported frequency mixes and outOfRange; not solver correctness or sizing')
    Path(output).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report))
    if failures:raise SystemExit(1)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('package');p.add_argument('--output',default='docs/nvt-ranges-review/parity.json');a=p.parse_args();run(a.package,a.output)
