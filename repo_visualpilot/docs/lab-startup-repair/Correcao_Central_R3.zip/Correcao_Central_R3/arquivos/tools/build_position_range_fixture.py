"""Extract only authentic validated NVT nodes required by the laboratory matrix."""
import argparse,hashlib,json
from pathlib import Path
from visualpilot.lab.scenario_matrix import CONTEXTS
p=argparse.ArgumentParser();p.add_argument('source');args=p.parse_args()
raw=Path(args.source).read_bytes();source=json.loads(raw)
ids={c[i] for c in CONTEXTS.values() for i in (3,5)}
nodes=[n for n in source['nodes'] if n['id'] in ids and n['validated']]
assert {n['id'] for n in nodes}==ids
result=dict(source,nodes=nodes,extraction={'source_sha256':hashlib.sha256(raw).hexdigest(),
    'scope':'six_authentic_preflop_nodes_for_position_matrix'})
Path('tests/fixtures/nvt_position_excerpt.json').write_text(json.dumps(result,separators=(',',':')),encoding='utf-8')
