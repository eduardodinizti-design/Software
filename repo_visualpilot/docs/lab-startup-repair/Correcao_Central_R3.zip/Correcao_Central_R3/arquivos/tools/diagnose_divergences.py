"""Controlled ablation: public-card budget versus all-in showdown budget."""
import json
from pathlib import Path
from visualpilot.lab.overnight import ROOT,atomic_json
from visualpilot.lab.scenario_matrix import make_case,condition_on_check
from visualpilot.lab.multistreet import SearchConfig,solve_postflop
from visualpilot.lab.opponent_models import size_sensitive_model
from visualpilot.lab.numerical_audit import audit_numerical_case
from visualpilot.agent.nvt_ranges import NvtRangeBook


def main():
    source=Path(json.loads((ROOT/'sessions/latest-cloud-run.json').read_text())['output'])
    output=ROOT/'docs/lab-divergences';output.mkdir(exist_ok=True)
    book=NvtRangeBook(ROOT/'tests/fixtures/nvt_position_excerpt.json');model=size_sensitive_model(.5)
    results={}
    for key in ('case-471','case-425'):
        spec=json.loads((source/(key+'-reference.input.json')).read_text())
        case=make_case(book,spec['case']['context'],spec['case']['texture'],hero=spec['case']['hero'])
        reference=json.loads((source/(key+'-reference.json')).read_text())
        rows=[]
        for samples,allin in ((24,500),(96,500),(24,5000)):
            runs=[]
            for seed in (11,23,47):
                cfg=SearchConfig(chance_method='stratified',chance_samples=samples,all_in_samples=allin,seed=seed)
                conditioned=condition_on_check(case,model,cfg)
                r=solve_postflop(case['hero'],case['board'],conditioned['range'],case['pot'],case['stack'],model,
                    'synthetic-size-sensitive-v1-aggression-.5',cfg,hero_position=case['hero_position'],opponent_checked=case['opponent_checked'])
                compact={k:r[k] for k in ('status','chosen','comparisons','seconds','nodes') if k in r}
                compact['seed']=seed;runs.append(compact)
                atomic_json(output/f'{key}-n{samples}-a{allin}-s{seed}.json',compact)
                print(key,samples,allin,seed,compact.get('chosen'),flush=True)
            rows.append(dict(chance_samples=samples,all_in_samples=allin,audit=audit_numerical_case(reference,runs),runs=runs))
            results[key]=dict(case=spec['case'],reference=reference['comparisons'],experiments=rows)
            atomic_json(output/'results.json',results)

if __name__=='__main__':main()
