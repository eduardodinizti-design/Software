"""Automatic experiments against labelled synthetic opponents, starting with NVT ranges."""
from functools import lru_cache
import json
import gzip
from pathlib import Path
import time
from visualpilot.agent.nvt_ranges import NvtRangeBook
from visualpilot.lab.postflop import range_from_nvt, rank7
from visualpilot.lab.range_state import RangeState
from visualpilot.lab.river_tree import solve_river, plan_rivers


@lru_cache(maxsize=None)
def category(combo, board):
    return rank7(tuple(combo)+tuple(board))[0]


def synthetic_model(aggression):
    """Engineering hypothesis only. Not fitted, not NVT strategy or GTO."""
    def model(combo,board,history,legal):
        strength=(.05,.3,.55,.7,.8,.9,.95,.99,1.)[category(combo,tuple(board))]
        row={a:0. for a in legal}
        aggressive=[a for a in legal if a.startswith(('bet:','raise:'))]
        attack=min(.95,aggression*(.2+.8*strength)) if aggressive else 0.
        if 'check' in legal:
            row['check']=1-attack
        else:
            call=min(1-attack,.1+.8*strength)
            row['call']=call
            row['fold']=1-attack-call
        for action in aggressive: row[action]=attack/len(aggressive)
        return row
    return model


def main():
    start=time.perf_counter()
    book=NvtRangeBook('tests/fixtures/nvt_range_excerpt.json')
    node=next(n for n in book.nodes.values() if n['spot']=='open_raise' and n['hero']=='BTN')
    hero=['Ah','Jh'];flop=['Kh','8h','2c'];turn=flop+['3d'];river=turn+['9s']
    weights,source=range_from_nvt(book,node['id'],'raise',hero+flop)
    experiments=[]
    for index,aggression in enumerate((.1,.25,.5,.75,.9)):
        model_id=f'synthetic-strength-v1-aggression-{aggression}'
        model=synthetic_model(aggression)
        state=RangeState(f'lab-{index}',hero,flop,weights,source)
        state.observe('flop-bet','bet:2',
            {c:model(c,flop,('check',),('check','bet:2'))['bet:2'] for c in state.weights},model_id)
        # Controlled line: initial pot6, Hero checks/calls2; both check turn. Pot10, effective18.
        state.reveal('turn',turn)
        state.observe('turn-check','check',
            {c:model(c,turn,('check',),('check','bet:4'))['check'] for c in state.weights},model_id)
        lookahead=None
        if index==2:
            lookahead=plan_rivers(hero,turn,state.weights,10,18,[3,7],[14,18],model,model_id)
        state.reveal('river',river)
        solution=solve_river(hero,river,state.weights,10,18,[3,7],[14,18],model,model_id)
        experiments.append(dict(profile=model_id,range_state=state.snapshot(),solution=solution,lookahead=lookahead))
        print(model_id,solution['chosen'],round(solution['ev'],4),flush=True)
    output=Path('docs/lab-postflop-tree')
    report=dict(scope='controlled_line_and_synthetic_opponent_not_GTO',
        line=['flop:hero_check','flop:villain_bet2','flop:hero_call2','turn:hero_check','turn:villain_check'],
        initial_pot=6,initial_effective_stack=20,river_pot=10,river_effective_stack=18,
        seconds=time.perf_counter()-start,experiments=experiments)
    # Compact JSON avoids repeating hundreds of thousands of indented lines in git.
    (output/'experiments.json.gz').write_bytes(gzip.compress(json.dumps(report,separators=(',',':')).encode(),mtime=0))
    print('seconds',report['seconds'],flush=True)

if __name__=='__main__': main()
