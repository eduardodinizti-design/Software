"""Read-only checks of an exported range package; no strategy generation."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path

def audit(path):
    raw=Path(path).read_bytes();data=json.loads(raw);nodes=data['nodes'];hands=data['hands']
    issues=Counter();examples={};sizes=Counter();zeros=0;ev_cells=0;near_zero=[]
    def issue(name,node,detail):
        issues[name]+=1
        if len(examples.setdefault(name,[]))<3:examples[name].append(dict(node=node['id'],detail=detail))
    seen=set()
    for n in nodes:
        if n['id'] in seen:issue('duplicate_id',n,n['id'])
        seen.add(n['id']);actions=n['actions'];out=set(n.get('outOfRange',[]))
        if any(type(i) is not int or i<0 or i>=len(hands) for i in out):issue('out_of_range_index',n,sorted(out))
        for a in actions:
            if a not in n['legalActions']:issue('action_not_legal',n,a)
            if len(n['freq'][a])!=169:issue('frequency_length',n,a)
            for f in n['freq'][a]:
                if not isinstance(f,(int,float)) or not math.isfinite(f) or not 0<=f<=1:issue('invalid_frequency',n,a)
                elif 0<f<.05:issue('frequency_below_five_percent',n,dict(action=a,frequency=f))
            if n['ev'] and len(n['ev'][a])!=169:issue('ev_length',n,a)
        for i,h in enumerate(hands):
            total=sum(n['freq'][a][i] for a in actions)
            if abs(total-1)>.002 and i not in out:issue('frequency_sum',n,dict(hand=h,sum=total))
            if n['ev']:
                for a in actions:
                    ev=n['ev'][a][i];ev_cells+=1
                    if ev is not None and (not isinstance(ev,(int,float)) or not math.isfinite(ev)):issue('invalid_ev',n,a)
                    if a!='fold' and ev==0 and n['freq'][a][i]==0:
                        zeros+=1
                        valid=[v[i] for v in n['ev'].values() if v[i] is not None]
                        tol=.03 if n['evUnit']=='bb' else .01
                        if i not in out and valid and max(valid)<tol and len(near_zero)<3:
                            near_zero.append(dict(node=n['id'],hand=h,chosen=a,ev_loss=max(0,max(valid)),
                                client_result='ACCEPTABLE_MIXED_ACTION from zero placeholder',documentation='treat EV as not calculated'))
        sizes.update(n.keys())
    return dict(file=Path(path).name,sha256=hashlib.sha256(raw).hexdigest(),format=data['format'],version=data['version'],
        engineCommit=data['engineCommit'],generatedAt=data['generatedAt'],validation=data['validation'],
        hands=len(hands),unique_hands=len(set(hands)),combos=sum(data['combos']),nodes=len(nodes),
        modes=dict(Counter(n['context']['mode'] for n in nodes)),stacks=dict(Counter(n['context']['stack'] for n in nodes)),
        tournament_stages=dict(Counter(n['context']['stage'] for n in nodes)),spots=dict(Counter(n['spot'] for n in nodes)),
        players=dict(Counter(n['context']['players'] for n in nodes)),validated=dict(Counter(str(n['validated']) for n in nodes)),
        ev_units=dict(Counter(str(n['evUnit']) for n in nodes)),node_fields=dict(sizes),
        issues=dict(issues),examples=examples,zero_ev_zero_frequency_nonfold=zeros,ev_cells=ev_cells,
        client_documentation_discrepancy_examples=near_zero)

def run(folder,output):
    root=Path(folder);reports=[audit(root/n) for n in ['nvt-ranges.json','nvt-ranges-validados.json']]
    full=json.loads((root/'nvt-ranges.json').read_text());validated=json.loads((root/'nvt-ranges-validados.json').read_text())
    expected={n['id']:n for n in full['nodes'] if n['validated']}
    actual={n['id']:n for n in validated['nodes']}
    comparison=dict(same_ids=expected.keys()==actual.keys(),same_contents=expected==actual)
    result=dict(packages=reports,validated_subset=comparison)
    Path(output).parent.mkdir(parents=True,exist_ok=True);Path(output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('folder');p.add_argument('--output',default='docs/nvt-ranges-review/audit.json')
    a=p.parse_args();run(a.folder,a.output)
