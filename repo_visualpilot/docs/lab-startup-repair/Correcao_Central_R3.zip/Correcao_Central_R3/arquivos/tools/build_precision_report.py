"""Small standalone result report; no live decisions or server required."""
from pathlib import Path
import html,json,gzip,zipfile
root=Path('docs/lab-exact-turn')
conclusions=json.loads((root/'conclusions.json').read_text())
summary=json.loads((root/'summary.json').read_text())
audit=json.loads((root/'evaluator-audit.json').read_text())
turn=next(r for r in summary if r['scenario']=='turn_draw')
flop=[r for r in summary if r['scenario']=='flop_draw']
sensitivity=json.loads(gzip.decompress((root/'model-sensitivity.json.gz').read_bytes()))
def table(headers,rows):
    return '<table><thead><tr>'+''.join('<th>'+html.escape(str(v))+'</th>' for v in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table>'
def action(a): return 'Check' if a=='check' else a.replace('bet:','Apostar ')+' BB'
body='''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>VisualPilot — Precisão do pós-flop</title><style>body{background:#10212a;color:#e3eef3;font:16px system-ui;line-height:1.6;margin:0}main{max-width:960px;padding:24px;margin:auto}section{background:#1a3440;padding:22px;border-radius:12px;margin:20px 0}h1{font-size:28px}h2{font-size:22px}table{border-collapse:collapse;width:100%}th,td{padding:9px;text-align:left;border-bottom:1px solid #526c78}.note{border-left:4px solid #e1b25f;padding:12px}small{color:#b8cbd4}@media(max-width:500px){main{padding:12px}section{padding:12px}td,th{padding:5px;font-size:13px}}</style><main><p>VISUALPILOT · LABORATÓRIO</p><h1>Mais precisão antes de ampliar o uso</h1><p>Testes concluídos com cálculo de todas as cartas de river no cenário de turn. Resultados sob modelo adversário sintético; sem execução de jogadas.</p>
<section><h2>Turn: instabilidade numérica resolvida</h2><p>Hero A♥ J♥ · Board K♥ 8♥ 2♣ 3♦ · Pote 10 BB · Stack efetivo 16 BB.</p><p>Três execuções retornaram os mesmos valores. Vitória, empate, bloqueadores e apostas futuras foram considerados.</p>'''
body+=table(['Ação','Valor esperado (BB)'],[(action(a),f'{v:.6f}') for a,v in sorted(turn['comparisons'].items(),key=lambda x:-x[1])])
body+='''<p class="note">A diferença entre apostar 3,33 e 6,67 BB é apenas 0,026 BB neste modelo. Precisão do cálculo não comprova que o comportamento adversário modelado é correto.</p></section><section><h2>Flop: permanece pendente</h2><p>Hero A♥ J♥ · Board K♥ 8♥ 2♣. O river é enumerado, mas os turns ainda são amostrados. As buscas discordaram sobre a melhor ação.</p>'''
body+=table(['Simulação','Escolha nessa busca','Tempo'],[(r['seed'],action(r['chosen']),f"{r['seconds']:.1f}s") for r in flop])
body+='''<p>Nenhuma escolha consolidada foi liberada para esse cenário. A próxima melhoria precisa reduzir a incerteza dos turns e o custo da busca.</p></section><section><h2>A hipótese sobre o adversário também importa</h2>'''
modelrows=[(r['aggression'],action(r['result']['chosen'])) for r in sensitivity]
modelrows.append((.5,action(turn['chosen'])));modelrows.sort()
body+=table(['Agressividade sintética','Escolha no turn'],modelrows)
body+='''<p>O mesmo cálculo exato pode indicar tamanhos diferentes quando a hipótese sobre o adversário muda. Essas hipóteses ainda não foram calibradas com dados reais.</p></section><section><h2>Validação e desempenho</h2><p>232 testes: 229 aprovados, 3 ignorados, nenhuma falha.</p><p>O novo avaliador coincidiu com a referência em todas as 2.598.960 mãos de cinco cartas e em 10 mil amostras de sete cartas. O cálculo isolado ficou cerca de 10 vezes mais rápido.</p><p>A primeira busca de flop caiu de 194 para 121 segundos, com os mesmos valores esperados. A busca completa ainda é cara; não é uma solução de tempo real homologada.</p><small>Este arquivo apresenta resultados pré-calculados. Não coleta telas nem controla aplicativos.</small></section></main></html>'''
path=Path('/workspace/entrega/VisualPilot_Precisao_Posflop.html');path.write_text(body,encoding='utf-8')
zip_path=path.with_suffix('.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(path,path.name)
    z.writestr('COMECE_AQUI.txt','Extraia o ZIP e abra VisualPilot_Precisao_Posflop.html com dois cliques.\nNao precisa instalar nada. O arquivo mostra resultados de laboratorio, sem operar mesas.\n')
with zipfile.ZipFile(zip_path) as z: assert z.testzip() is None
(root/zip_path.name).write_bytes(zip_path.read_bytes())
