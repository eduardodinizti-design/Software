"""Benchmark virtual com recortes reais; não substitui o teste no Windows."""
from __future__ import annotations

import argparse
import json
import statistics
import tempfile
import threading
from pathlib import Path
from queue import Empty, Queue
from time import monotonic

import numpy as np
from PIL import Image

from visualpilot.pppoker.observer.runtime import PerceptionSession


ROOT = Path(__file__).resolve().parents[1]


def run(tables: int, workers: int, timeout: float = 60.0):
    paths = [ROOT / "tests/fixtures/actions/right_99.png"]
    images = [np.array(Image.open(path).convert("RGB")) for path in paths]
    expected = [(["5c", "2s"], [])]
    events = Queue(1024)
    stop = threading.Event()
    first, confirmed, latest = {}, {}, {}
    latencies = []
    began = monotonic()
    next_feed = began
    tick = 0
    with tempfile.TemporaryDirectory(prefix="visualpilot-benchmark-") as folder:
        session = PerceptionSession(folder, stop, events, workers=workers)
        thread = threading.Thread(target=session.run, kwargs={"capture": False})
        thread.start()
        try:
            while monotonic() - began < timeout and len(confirmed) < tables:
                now = monotonic()
                if now >= next_feed:
                    tick += 1
                    for index in range(tables):
                        image = images[index % len(images)].copy()
                        # Animação fora das regiões legíveis: o cache por ROI deve
                        # ignorá-la, enquanto um hash da mesa inteira mudaria.
                        image[400:404, 400:404] = tick % 255
                        session.frames.put({"table_key": str(index), "number": index + 1}, image)
                    next_feed = now + .5
                try:
                    event = events.get(timeout=.05)
                except Empty:
                    continue
                if event["kind"] != "reading":
                    continue
                reading = event["reading"]
                index = int(event["table"])
                latest[index] = event
                if reading.get("hero") != expected[index % len(expected)][0]:
                    continue
                if reading.get("board") != expected[index % len(expected)][1]:
                    continue
                first.setdefault(index, monotonic() - began)
                if not event["cached"]:
                    latencies.append(event["latency"])
                if event["field_confirmation"]["hero"]["confirmed"]:
                    confirmed.setdefault(index, monotonic() - began)
        finally:
            stop.set()
            thread.join(25)
        if thread.is_alive():
            raise RuntimeError("Sessão não encerrou após o benchmark")
        now = monotonic()
        fresh = sum(now - event["observed"] <= 5 for event in latest.values())
        return {
            "tables": tables,
            "workers": workers,
            "recognized": len(first),
            "confirmed": len(confirmed),
            "all_first_seconds": max(first.values()) if len(first) == tables else None,
            "all_confirmed_seconds": max(confirmed.values()) if len(confirmed) == tables else None,
            "fresh_at_finish": fresh,
            "ocr_latency_median_seconds": statistics.median(latencies) if latencies else None,
            "ocr_latency_max_seconds": max(latencies) if latencies else None,
            "metrics": {key: value for key, value in session.metrics.items()
                        if key not in {"latencies", "ocr_latencies", "cached_latencies", "tables"}},
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tables", type=int, default=6)
    parser.add_argument("--workers", type=int, nargs="+", default=[2])
    parser.add_argument("--output", default="docs/pppoker-performance.json")
    args = parser.parse_args()
    if not 1 <= args.tables <= 6 or any(not 1 <= count <= 4 for count in args.workers):
        parser.error("Use 1–6 mesas e 1–4 processos")
    results = [run(args.tables, workers) for workers in args.workers]
    payload = {
        "scope": "Linux; recortes reais repetidos como seis mesas virtuais; sem descoberta, captura ou GUI Windows.",
        "results": results,
    }
    target = Path(args.output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    if any(row["confirmed"] != args.tables for row in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
