"""Validate the exact frozen Central in clean and malformed user profiles."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import uuid
from urllib.request import urlopen


def matches_startup(state, token, build, url):
    """A Windows venv/bootloader may spawn a different PID; bind by nonce."""
    return (state.get('validation_token') == token and bool(token)
            and state.get('build') == build and state.get('url') == url
            and state.get('phase') == 'ready')


def stop_process_tree(process):
    if process.poll() is not None:
        return
    if sys.platform == 'win32':
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    else:
        process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=10)


def validate(root):
    root=root.resolve()
    report=dict(platform=sys.platform,status='failed',scope='frozen_central_identified_http_startup',profiles=[])
    try:
        if sys.platform!='win32':raise RuntimeError('Este teste exige Windows e executaveis Windows.')
        from visualpilot.viz.launcher import BUILD_ID
        for malformed in (False,True):
            try:
                with urlopen('http://127.0.0.1:8501/_stcore/health',timeout=1):
                    raise RuntimeError('Feche a Central aberta na porta 8501 antes de validar.')
            except OSError:pass
            with tempfile.TemporaryDirectory() as profile:
                settings=Path(profile)/'.streamlit';settings.mkdir()
                if malformed:(settings/'credentials.toml').write_text('email = ""')
                (settings/'config.toml').write_text('[server]\nheadless=false\nenableCORS=false\n')
                token=uuid.uuid4().hex
                env={k:v for k,v in os.environ.items() if not k.startswith('STREAMLIT_')}
                env.update(USERPROFILE=profile,HOME=profile,VISUALPILOT_VALIDATE_STARTUP=token)
                folder=root/'VisualPilot_Central';process=None
                try:
                    with (root/f'startup-validation-{malformed}.log').open('wb') as log:
                        process=subprocess.Popen([str(folder/'VisualPilot_Central.exe')],cwd=profile,env=env,
                            stdin=subprocess.DEVNULL,stdout=log,stderr=log)
                        deadline=time.monotonic()+60;ready=False
                        while time.monotonic()<deadline:
                            if process.poll() is not None:raise RuntimeError(f'Central encerrou: {process.returncode}')
                            try:
                                state=json.loads((folder/'central_status.json').read_text())
                                if matches_startup(state, token, BUILD_ID, 'http://127.0.0.1:8501'):
                                    with urlopen('http://127.0.0.1:8501/_stcore/health',timeout=1) as response:
                                        ready=response.status==200
                                    if ready:break
                            except (OSError,ValueError):pass
                            time.sleep(.25)
                        if not ready:raise TimeoutError('Central não iniciou com identidade confirmada em 60 segundos.')
                        report['profiles'].append(dict(malformed_credentials=malformed,status='passed',build=BUILD_ID))
                finally:
                    if process is not None and process.poll() is None:
                        stop_process_tree(process)
        report['status']='passed'
    except Exception as exc:report['error']=str(exc)
    (root/'startup-validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report


if __name__=='__main__':
    result=validate(Path(__file__).resolve().parents[1]/'dist');print(json.dumps(result))
    raise SystemExit(0 if result['status']=='passed' else 1)
