import json
from pathlib import Path
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':1100})
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('http://127.0.0.1:8839/VisualPilot_Posflop_Experimentos.html')
    assert page.locator('#profile option').count()==5
    results=[]
    for i in range(5):
        page.select_option('#profile',str(i))
        assert page.locator('#actions tr').count()==3
        results.append(page.locator('#rootEv').inner_text())
        for option in page.locator('#node option').all():
            page.select_option('#node',option.get_attribute('value'))
            assert page.locator('#actions tr.best').count()==1
    page.select_option('#profile','2')
    assert page.locator('#river option').count()==47
    page.select_option('#river','Ac')
    assert 'A♣' in page.locator('#board').inner_text()
    page.screenshot(path='/workspace/entrega/VisualPilot_Posflop_Experimentos.png',full_page=True)
    page.set_viewport_size({'width':390,'height':844})
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.click('#play');page.wait_for_timeout(1800)
    assert page.locator('#profile').input_value()=='1'
    page.click('#play');page.wait_for_timeout(1800)
    assert page.locator('#profile').input_value()=='1'
    assert not errors,errors
    Path('docs/lab-postflop-tree/browser.json').write_text(json.dumps(dict(passed=True,
        profiles=results,rivers=46,mobile_width=390,autoplay_pause=True,js_errors=errors),indent=2))
    browser.close()
