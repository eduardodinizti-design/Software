"""Reproducible lab-only sensitivity experiments; no user labels required."""
import argparse
import json
from pathlib import Path
from visualpilot.agent.nvt_ranges import NvtRangeBook
from visualpilot.lab.postflop import compare_actions, range_from_nvt


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--ranges', default='tests/fixtures/nvt_range_excerpt.json')
    parser.add_argument('--output', default='docs/lab-postflop/experiments.json')
    args=parser.parse_args()
    book=NvtRangeBook(args.ranges)
    node=next(n for n in book.nodes.values() if n['spot']=='open_raise' and n['hero']=='BTN'
              and n['context']['mode']=='chip_ev' and n['context']['stack']==25)
    scenarios=[('top_pair_dry','Ah Qd','As 7c 2d'),
               ('flush_draw','Ah Jh','Kh 8h 2c'),
               ('turn_completed_draw','Ah Jh','Kh 8h 2c 3h'),
               ('river_missed_draw','Ah Jh','Kh 8h 2c 3d 9s'),
               ('river_full_house','As Ad','Ac 7h 7d 2s 3c')]
    results=[]
    for name,h,b in scenarios:
        hero=h.split();board=b.split()
        combos,source=range_from_nvt(book,node['id'],'raise',hero+board)
        variants=[]
        for fold in (0.,.35,.7):
            bets=[2.,4.,6.]
            response={bet:{combo:fold for combo in combos} for bet in bets}
            result=compare_actions(hero,board,combos,6.,20.,bets=bets,
                                   fold_by_combo=response,samples=400,seed=20261030)
            result['response_hypothesis']=f'Uniform fold probability {fold}; sensitivity test only'
            variants.append(result)
        results.append(dict(scenario=name,range_source=source,variants=variants))
        print(name,[(v['response_hypothesis'],v['best_under_model']['action'],
                     v['best_under_model']['amount'],round(v['best_under_model']['ev'],3)) for v in variants],flush=True)
    path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(dict(scope='offline_experiments_not_policy',
        warning='Preflop BTN range held fixed; no postflop action conditioning or solver validation.',
        scenarios=results),indent=2),encoding='utf-8')

if __name__=='__main__':main()
