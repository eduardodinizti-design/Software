"""Multi-street experiments; refine unstable seed results without inventing answers."""
import gzip
import json
from pathlib import Path
from visualpilot.lab.multistreet import SearchConfig, compare_seeds
from visualpilot.lab.opponent_models import size_sensitive_model
from visualpilot.agent.nvt_ranges import NvtRangeBook
from visualpilot.lab.postflop import range_from_nvt


def main():
    root=Path('docs/lab-multistreet');root.mkdir(exist_ok=True)
    book=NvtRangeBook('tests/fixtures/nvt_range_excerpt.json')
    node=next(n for n in book.nodes.values() if n['spot']=='open_raise')
    cases=[('flop_top_pair','Ah Qd','As 7c 2d',6,18),
           ('flop_flush_draw','Ah Jh','Kh 8h 2c',6,18),
           ('turn_flush','Ah Jh','Kh 8h 2c 3h',10,16),
           ('turn_missed_draw','Ah Jh','Kh 8h 2c 3d',10,16),
           ('river_missed_draw','Ah Jh','Kh 8h 2c 3d 9s',10,16)]
    rows=[]
    for name,h,b,pot,stack in cases:
        hero=h.split();board=b.split()
        weights,source=range_from_nvt(book,node['id'],'raise',hero+board)
        attempts=[]
        for samples in (3,6):
            result=compare_seeds(hero,board,weights,pot,stack,size_sensitive_model(.5),
                'synthetic-size-sensitive-v1-aggression-.5',
                SearchConfig(chance_samples=samples,all_in_samples=500,max_nodes=150000))
            attempts.append(result)
            print(name,'samples',samples,result['status'],result['chosen'],
                  {a:round(v,4) for a,v in result.get('mean_ev',{}).items()},flush=True)
            if result['status']=='experimental' or len(board)==5: break
        row=dict(scenario=name,provenance=source,attempts=attempts)
        rows.append(row)
        (root/f'{name}.json.gz').write_bytes(gzip.compress(json.dumps(row,separators=(',',':')).encode(),mtime=0))
    summary=[dict(scenario=r['scenario'],status=r['attempts'][-1]['status'],
                  action=r['attempts'][-1]['chosen'],attempts=len(r['attempts']),
                  means=r['attempts'][-1].get('mean_ev'),
                  seconds=sum(run['seconds'] for attempt in r['attempts'] for run in attempt['runs'])) for r in rows]
    (root/'summary.json').write_text(json.dumps(summary,indent=2))

if __name__=='__main__':main()
