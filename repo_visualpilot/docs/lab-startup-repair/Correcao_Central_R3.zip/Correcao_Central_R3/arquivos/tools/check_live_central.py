"""Real browser + TCP + recorded fixture; not physical Windows validation."""
import os,sys,time,socket,subprocess,tempfile,threading,json
from pathlib import Path
import cv2
from playwright.sync_api import sync_playwright
from visualpilot.pppoker.stream_node import encode_frame,prepare_capture

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/lab-live-central'
def freeport():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]

def main():
    web,port=freeport(),freeport();stop=threading.Event();failures=[]
    with tempfile.TemporaryDirectory() as d:
        folder=Path(d);(folder/'stream_config.ini').write_text(f'[central]\nlisten_host=127.0.0.1\nport={port}\n')
        (folder/'.streamlit').mkdir();(folder/'.streamlit/credentials.toml').write_text('email = ""')
        env=dict(os.environ,HOME=d,USERPROFILE=d,PYTHONPATH=str(ROOT),STREAMLIT_SERVER_HEADLESS='true',STREAMLIT_BROWSER_GATHER_USAGE_STATS='false')
        log=(OUT/'browser-server.log').open('w')
        proc=subprocess.Popen([sys.executable,'-c',f"import sys; sys.stdin=None; from visualpilot.viz import launcher; launcher.PANEL_URL='http://127.0.0.1:{web}'; launcher.main()"],cwd=folder,env=env,stdout=log,stderr=log)
        def send():
            rgb=prepare_capture(cv2.cvtColor(cv2.imread(str(ROOT/'tests/fixtures/actions/right_99.png')),cv2.COLOR_BGR2RGB))
            for _ in range(100):
                try:conn=socket.create_connection(('127.0.0.1',port),timeout=2);break
                except OSError:
                    if stop.wait(.1):return
            else:failures.append('receiver not listening');return
            with conn:
                seq=0
                while not stop.is_set():
                    seq+=1
                    try:conn.sendall(encode_frame('lab','visual-test','one',seq,rgb))
                    except OSError as exc:failures.append(str(exc));return
                    stop.wait(.3)
        thread=None
        try:
            with sync_playwright() as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
                page=browser.new_page(viewport={'width':1280,'height':1800});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                for _ in range(100):
                    try:page.goto(f'http://127.0.0.1:{web}');break
                    except Exception:time.sleep(.1)
                page.get_by_role('button',name='Iniciar coleta',exact=True).click()
                thread=threading.Thread(target=send,daemon=True);thread.start()
                page.get_by_text('Cartas do Hero: 5c · 2s',exact=True).wait_for(timeout=60000)
                page.get_by_text('Tempo desde a observação dos botões',exact=True).wait_for(timeout=60000)
                page.get_by_role('button',name='Marcar decisão para revisão',exact=True).click()
                page.get_by_text('Momento marcado no diário. Nenhuma jogada foi executada.',exact=True).wait_for()
                page.evaluate("document.querySelector('[data-testid=stMain]').scrollTo(0,0)")
                page.screenshot(path=str(OUT/'central-live.png'),full_page=True)
                page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(OUT/'central-mobile.png'),full_page=True)
                overflow=page.evaluate('document.documentElement.scrollWidth > window.innerWidth')
                stop.set();thread.join(5)
                page.get_by_text('Transmissão sem imagens recentes. A prévia acima está congelada.',exact=True).wait_for(timeout=20000)
                page.screenshot(path=str(OUT/'central-frozen.png'),full_page=True)
                page.get_by_role('button',name='Parar coleta',exact=True).click()
                time.sleep(2)
                journals=list(folder.glob('sessions/*/*/acompanhamento/eventos.jsonl'))
                entries=[json.loads(line) for f in journals for line in f.read_text().splitlines()]
                result=dict(browser_errors=errors,sender_errors=failures,mobile_overflow=overflow,
                    manual_markers=sum(e['kind']=='manual_review_marker' for e in entries),
                    reading_samples=sum(e['kind']=='reading_sample' for e in entries),
                    frozen_warning=True,source='recorded real fixture over local TCP; Linux')
                (OUT/'browser.json').write_text(json.dumps(result,indent=2))
                assert not errors and not failures and not overflow and result['manual_markers'] and result['reading_samples'],result
                browser.close();print(result)
        finally:
            stop.set()
            if thread:thread.join(5)
            proc.terminate()
            try:proc.wait(timeout=15)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
            log.close()

if __name__=='__main__':main()
