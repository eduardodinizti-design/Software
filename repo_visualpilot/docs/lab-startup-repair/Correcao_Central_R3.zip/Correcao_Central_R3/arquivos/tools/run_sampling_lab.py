"""Paired sampling comparison against exact-turn values, then independent flop runs."""
import gzip,json,math
from dataclasses import replace
from pathlib import Path
from visualpilot.agent.nvt_ranges import NvtRangeBook
from visualpilot.lab.postflop import range_from_nvt
from visualpilot.lab.multistreet import SearchConfig,solve_postflop
from visualpilot.lab.opponent_models import size_sensitive_model


def main():
    root=Path('docs/lab-sampling');root.mkdir(exist_ok=True)
    book=NvtRangeBook('tests/fixtures/nvt_range_excerpt.json')
    node=next(n for n in book.nodes.values() if n['spot']=='open_raise')
    cases=[('turn_draw','Ah Jh','Kh 8h 2c 3d'),('turn_flush','Ah Jh','Kh 8h 2c 3h'),
           ('turn_top_pair','Ah Qd','As 7c 2d 9h')]
    references=[];rows=[];traces=[]
    model=size_sensitive_model(.5);model_id='synthetic-size-sensitive-v1-aggression-.5'
    for name,h,b in cases:
        hero=h.split();board=b.split();weights,source=range_from_nvt(book,node['id'],'raise',hero+board)
        ref=solve_postflop(hero,board,weights,10,16,model,model_id,SearchConfig(exact_turn=True))
        assert ref['status']=='experimental' and ref['exact_under_model']
        references.append(dict(scenario=name,source=source,result=ref))
        exact=ref['comparisons'];best=max(exact.values())
        for count in (3,6):
            for seed in (11,23,47,83,101):
                for method in ('random','stratified'):
                    r=solve_postflop(hero,board,weights,10,16,model,model_id,
                        SearchConfig(chance_samples=count,chance_method=method,seed=seed))
                    assert r['status']=='experimental'
                    row=dict(scenario=name,count=count,seed=seed,method=method,chosen=r['chosen'],
                        rmse=math.sqrt(sum((r['comparisons'][a]-v)**2 for a,v in exact.items())/len(exact)),
                        regret_bb=best-exact[r['chosen']],seconds=r['seconds'],comparisons=r['comparisons'])
                    rows.append(row)
        print(name,'completed',flush=True)
        (root/'paired-results.json').write_text(json.dumps(rows,indent=2))
    aggregate=[]
    for count in (3,6):
        for method in ('random','stratified'):
            group=[r for r in rows if r['method']==method and r['count']==count]
            aggregate.append(dict(count=count,method=method,runs=len(group),
                mean_rmse=sum(r['rmse'] for r in group)/len(group),
                mean_regret_bb=sum(r['regret_bb'] for r in group)/len(group),
                decisions_within_003bb=sum(r['regret_bb']<=.03 for r in group),
                total_seconds=sum(r['seconds'] for r in group)))
    (root/'summary.json').write_text(json.dumps(dict(aggregate=aggregate,default_changed=False,
        scope='three_controlled_turns_one_synthetic_model_not_general_validation'),indent=2))
    (root/'references.json.gz').write_bytes(gzip.compress(json.dumps(references,separators=(',',':')).encode(),mtime=0))
    print(json.dumps(aggregate),flush=True)
    # Paired flop check: no exact ground truth, so this measures agreement, not correctness.
    weights,source=range_from_nvt(book,node['id'],'raise',['Ah','Jh','Kh','8h','2c'])
    flop=[]
    for method in ('random','stratified'):
        for seed in (11,23,47):
            result=solve_postflop(['Ah','Jh'],['Kh','8h','2c'],weights,6,18,model,model_id,
                SearchConfig(chance_method=method,chance_samples=3,seed=seed))
            flop.append(dict(method=method,seed=seed,source=source,result=result))
            print('flop',method,seed,result['chosen'],round(result['seconds'],2),flush=True)
            (root/'flop-runs.json.gz').write_bytes(gzip.compress(json.dumps(flop,separators=(',',':')).encode(),mtime=0))
    conclusion={method:dict(choices=[r['result']['chosen'] for r in flop if r['method']==method],
        seed_stable=len({r['result']['chosen'] for r in flop if r['method']==method})==1)
        for method in ('random','stratified')}
    (root/'flop-summary.json').write_text(json.dumps(conclusion,indent=2))

if __name__=='__main__':main()
