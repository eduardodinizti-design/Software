"""Apply the numerical validation rule to every completed matrix cell."""
from pathlib import Path
import json,gzip
from visualpilot.lab.numerical_audit import audit_numerical_case
root=Path('docs/lab-position-matrix')
rows=json.loads((root/'turn-summary.json').read_text());assert len(rows)==30
results=[]
for row in rows:
    source=json.loads(gzip.decompress((root/(row['id'].replace(':','-')+'.json.gz')).read_bytes()))
    audit=audit_numerical_case(source['reference'],source['sampled'])
    results.append(dict(id=row['id'],**audit))
report=dict(cases=results,accepted=sum(r['numerically_accepted'] for r in results),
    needs_refinement=sum(not r['numerically_accepted'] for r in results),
    stable_but_inaccurate=[r['id'] for r in results if r.get('seed_stable') and not r['numerically_accepted']],
    worst_cases=sorted(results,key=lambda r:r.get('worst_regret',float('inf')),reverse=True)[:5])
(root/'numerical-audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
