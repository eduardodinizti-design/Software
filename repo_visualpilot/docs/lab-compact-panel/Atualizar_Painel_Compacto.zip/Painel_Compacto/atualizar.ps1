$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    $picker = New-Object System.Windows.Forms.FolderBrowserDialog
    $picker.Description = 'Selecione a pasta da Central no notebook: onde estao VisualPilot_Central.exe e _internal.'
    if ($picker.ShowDialog() -ne 'OK') { exit 0 }
    $folder = $picker.SelectedPath
    $exe = Join-Path $folder 'VisualPilot_Central.exe'
    $relative = '_internal/visualpilot/viz/app.py'
    $destination = Join-Path $folder $relative
    if (-not (Test-Path $exe) -or -not (Test-Path $destination)) { throw 'Esta nao e a pasta completa da Central. Nenhum arquivo foi alterado.' }
    $versionPath = Join-Path $folder 'VERSAO_CENTRAL.json'
    if (-not (Test-Path $versionPath)) { throw 'Versao nao identificada. Selecione a pasta VisualPilot_Central_R2. Nenhum arquivo foi alterado.' }
    $version = Get-Content $versionPath -Raw | ConvertFrom-Json
    if ($version.build -ne 'central-live-20261030-r2') { throw 'Central anterior incompativel. Selecione VisualPilot_Central_R2. Nenhum arquivo foi alterado.' }
    $expected = (Get-Content "$PSScriptRoot\app.sha256" -Raw).Trim()
    $actual = (Get-FileHash "$PSScriptRoot\app.py" -Algorithm SHA256).Hash.ToLower()
    if ($actual -ne $expected) { throw 'Atualizacao incompleta. Extraia o ZIP inteiro.' }
    Get-Process -Name VisualPilot_Central -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $exe } | Stop-Process -Force
    $stamp = Get-Date -Format yyyyMMddHHmmss
    Copy-Item $destination "$destination.backup-$stamp"
    Copy-Item "$PSScriptRoot\app.py" $destination -Force
    $manifestPath = Join-Path $folder 'VERSAO_CENTRAL.json'
    if (Test-Path $manifestPath) {
        Copy-Item $manifestPath "$manifestPath.backup-$stamp"
        $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
        $manifest.files | Add-Member -NotePropertyName $relative -NotePropertyValue $actual -Force
        $manifest | Add-Member -NotePropertyName panel_revision -NotePropertyValue 'compact-v1' -Force
        $manifest | ConvertTo-Json -Depth 10 | Set-Content $manifestPath -Encoding UTF8
    }
    Write-Host 'Painel compacto instalado. Configuracoes de rede e registros preservados.'
    Start-Process -FilePath $exe -WorkingDirectory $folder
} catch {
    Write-Host "ERRO: $($_.Exception.Message)"
    exit 1
}
